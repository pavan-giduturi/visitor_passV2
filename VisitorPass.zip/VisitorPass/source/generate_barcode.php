<?php

 $text=$_POST['barvalue'];
 return "<img alt='testing' src='barcode/barcode.php?codetype=Code39&size=40&text=".$text."&print=true'/>";

?>