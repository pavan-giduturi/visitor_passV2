<?php 

$connect = mysqli_connect('localhost','root','','db_cbic');

// if($connect){
// 	echo "success";
// }else{
// 	echo "failed";
// }
$data = array();
$phoneno = $_GET['phn'];
if(! $connect ) {
      die('Could not connect: ' . mysqli_error());
   }
   // echo 'Connected successfully<br>';
$query = "select * from tbl_passes WHERE  Phone='".$phoneno."'";
   $result = mysqli_query($connect,$query);
   
   while($row = mysqli_fetch_assoc($result))
   {   
   $data = $row;
   
   }
   
    echo json_encode($data);
   // mysqli_close($connect);
?>