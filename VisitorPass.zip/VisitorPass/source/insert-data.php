<?php 

$connect = mysqli_connect('localhost','root','','db_cbic');

// if($connect){
// 	echo "success";
// }else{
// 	echo "failed";
// pass_no->".$_POST["pass_no"]."','
// }
if ($connect->connect_error) {
   die("Connection failed: " . $connect->connect_error);
} 
// if(isset($_POST["submit"])){

	// echo $_POST['pass_no'];exit;
           
            $sql = "INSERT INTO tbl_passes(SLNO,Name,Designation,Floor,Add_content,ID_Proof,Phone,Person_to_be_visited,part_b_Designation,Purpose_of_visit,in_time,out_time,Remarks,profile_image,PDate)VALUES ('".$_POST["SLNO"]."','".$_POST["Name"]."','".$_POST["Designation"]."','".$_POST["Floor"]."','".$_POST["Add_content"]."','".$_POST["ID_Proof"]."','".$_POST["Phone"]."','".$_POST["Person_to_be_visited"]."','".$_POST["part_b_Designation"]."','".$_POST["Purpose_of_visit"]."','".$_POST["in_time"]."','".$_POST["out_time"]."','".$_POST["Remarks"]."','".$_POST["profile_image"]."','".$_POST["PDate"]."')";

            // echo $sql;exit;
            // $text=$_POST['SLNO'];
            if (mysqli_query($connect, $sql)) { 
          		header("location:".base_url(''));
            } else {
               echo "Error: " . $sql . "" . mysqli_error($connect);
            }
            $connect->close();
         // }
?>