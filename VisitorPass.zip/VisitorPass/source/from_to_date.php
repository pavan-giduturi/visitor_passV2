<?php 
$connect = mysqli_connect('localhost','root','','db_cbic');

$from = $_GET['from'];
$to = $_GET['to'];
$query = "select * from tbl_passes WHERE STR_TO_DATE(PDate, '%d-%m-%Y')  BETWEEN '".$from."' AND '".$to."'";

$result=mysqli_query($connect,$query);

echo "<div class='table-responsive text-center'><h2><span class='label label-primary'>".$from."</span> To <span class='label label-primary'>".$to."</span></h2><table border='1' class='table table-striped'>
<tr>
<td align=center> <b>S.No</b></td>
<td align=center> <b>Name</b></td>
<td align=center> <b>Image</b></td>
<td align=center><b>Designation</b></td>
<td align=center><b>Phone</b></td>
<td align=center><b>Address</b></td></td>
<td align=center><b>Person to be visited</b></td></td>
<td align=center><b>Floor</b></td>
<td align=center><b>In time</b></td>
<td align=center><b>Out time</b></td></tr>";
// $data = mysqli_fetch_row($result);
// print_r($data);
$sno=1;
while($data = mysqli_fetch_assoc($result))
{   
    echo "<tr>";
    echo "<td align=center>".$sno++."</td>";
    echo "<td align=center>".$data['Name']."</td>";
    echo "<td align=center><img src=upload/".$data['profile_image']."/></td>";
    echo "<td align=center>".$data['Designation']."</td>";
    echo "<td align=center>".$data['Phone']."</td>";
    echo "<td align=center>".$data['Add_content']."</td>";
    echo "<td align=center>".$data['Person_to_be_visited']."</td>";
    echo "<td align=center>".$data['Floor']."</td>";
    echo "<td align=center>".$data['in_time']."</td>";
    echo "<td align=center>".$data['out_time']."</td>";
    echo "</tr>";
}
echo "</table><div>";


?>