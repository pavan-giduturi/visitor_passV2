<?php date_default_timezone_set('Asia/Calcutta'); $pdate = date('d-m-Y');?>
<?php 

$connect = mysqli_connect('localhost','root','','db_cbic');
$sql = "SELECT * FROM tbl_passes where PDate='".$pdate."' ORDER BY id ASC";
$result = mysqli_query($connect, $sql);

// $row=mysqli_fetch_assoc($result);


// echo $data['Name'];
            
           

            // echo  $pbc[1];


          
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1.0">
	<title>Reports</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- <script type="text/javascript" src="jquery-1.3.2.js"> </script> -->

 <script type="text/javascript">

 $(document).ready(function() {
    $("#display").click(function() { 
    	// alert();
 	var from = document.getElementById('from_date').value;
 	var to = document.getElementById('to_date').value;
    // alert(from);               
    // alert(to);               

            $("#responsecontainer").html(''); 
      $.ajax({    //create an ajax request to display.php
        type: "GET",
        url: "from_to_date.php",
        data : {'from':from,'to':to},             
        dataType: "html",   //expect html to be returned                
        success: function(response){                    
            $("#responsecontainer").html(response); 
            //alert(response);
        }

    });
});
});



 $(document).ready(function() {
    $("#select_today").click(function() { 
    	// alert();
 	var selectdate = document.getElementById('select_date').value;
    // alert(from);               
    // alert(to);               

            $("#responsecontainer").html(''); 
      $.ajax({    //create an ajax request to display.php
        type: "GET",
        url: "select_date.php",
        data : {'today':selectdate},             
        dataType: "html",   //expect html to be returned                
        success: function(response){                    
            $("#responsecontainer").html(response); 
            //alert(response);
        }

    });
});
});

</script>

</head>
<body>
	<div>
		<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">CBIC</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
     
      <form class="navbar-form navbar-left form-inline">
			<div class="form-group">
			<label for="exampleInputName2">From :</label>
			<input type="date" class="form-control"  name="from_date" id="from_date">
			</div>
			<div class="form-group">
			<label for="exampleInputEmail2">To :</label>
			<input type="date" class="form-control"  name="to_date" id="to_date">
			</div>
			  <button type="button" id="display" class="btn btn-default">Submit</button>
      </form>


    <div class="nav navbar-nav navbar-right">
    	<form method="post" class="navbar-form navbar-left form-inline">
			<div class="form-group">
			<label for="exampleInputName2"> Date :</label>
			<input type="date" class="form-control" id="select_date" name="select_date">
			</div>
			<button type="button" id="select_today" class="btn btn-default">Submit</button>
      </form>
    </div><!-- /.navbar-collapse -->
    </div>
  </div><!-- /.container-fluid -->
</nav>
	</div>
<h3 class="text-center">Visitor Pass Details</h3>
<div id="responsecontainer" align="center">
<h2 class="text-center"><span class='label label-primary'><?php echo $pdate; ?></span></h2>
<div class='table-responsive'><table border='1' class='table table-striped'>
<tr>
<td align=center> <b>S.No</b></td>
<td align=center> <b>Name</b></td>
<td align=center> <b>Image</b></td>
<td align=center><b>Designation</b></td>
<td align=center><b>Phone</b></td>
<td align=center><b>Address</b></td></td>
<td align=center><b>Person to be visited</b></td></td>
<td align=center><b>Floor</b></td>
<td align=center><b>In time</b></td>
<td align=center><b>Out time</b></td>
</tr>

<?php $sno=1; while($row=mysqli_fetch_assoc($result)) { ?>
	<tr>
	<td align=center><?php echo $sno++;?></td>
	<td align=center><?php echo $row['Name'] ;?></td>
	<td align=center><img src="upload/<?php echo $row['profile_image'] ;?>"/></td>
	<td align=center><?php echo $row['Designation'] ;?></td>
	<td align=center><?php echo $row['Phone'] ;?></td>
	<td align=center><?php echo $row['Add_content'] ;?></td>
	<td align=center><?php echo $row['Person_to_be_visited'] ;?></td>
	<td align=center><?php echo $row['Floor'] ;?></td>
	<td align=center><?php echo $row['in_time'] ;?></td>
	<td align=center><?php echo $row['out_time'] ;?></td>
	</tr>
<?php } ?>
</div>


</body>
</html>