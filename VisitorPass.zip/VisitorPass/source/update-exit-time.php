<?php 

$connect = mysqli_connect('localhost','root','','db_cbic');

// if($connect){
//    echo "success";
// }else{
//    echo "failed";
// }
$mystring = $_POST['barcodenumber'];
$findme   = 'CBIC';
$pos = strpos($mystring, $findme);
if ($pos == false) {
$barscan = $_POST['barcodenumber'];
} else {
$bar = $_POST['barcodenumber'];
$pbc = explode('CBIC', $bar);
$barscan = $pbc[1];
    
}


date_default_timezone_set('Asia/Calcutta');
$out_time = date('Y-m-d H:i:s');

$query1 = "SELECT * FROM `tbl_passes` WHERE Phone='".$barscan."' OR SLNO='".$barscan."' ORDER BY id DESC LIMIT 1";

$identity = mysqli_query($connect,$query1);
$iddata = mysqli_fetch_assoc($identity);

$id = $iddata['id'];



if(! $connect ) {
      die('Could not connect: ' . mysqli_error());
   }
   // echo 'Connected successfully<br>';
$query = "select * from tbl_passes WHERE id='".$id."'";
   $result = mysqli_query($connect,$query);
   $row = mysqli_fetch_assoc($result);
            $snval = $row['Name'];
            $phoneval = $row['Phone'];
   $sql = "UPDATE tbl_passes SET out_time='".$out_time."' WHERE id='".$id."'";
   
   if (mysqli_query($connect, $sql)) {
      echo "The Time of Exit Updated successfully ".$snval."Your Phone number ".$phoneval;
   } else {
      echo "Error updating record: " . mysqli_error($connect);
   }
   mysqli_close($connect);
?>