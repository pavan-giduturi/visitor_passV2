<?php  
/**
 * Main_Model Model
 */
class Main_Model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}


	public function getSite()
	{
		$query = $this->db->select("*")->from("tbl_site_settings")->get()->row();
		return $query;	
	}

	public function getData($table)
	{
		$query = $this->db->select("*")->from($table)->get()->result();
		return $query;
	}
  function mail_exists($email)
  {
      $this->db->where(array('email'=>$email));
      
      $query = $this->db->get('tbl_admin');

      if ($query->num_rows() > 0){
          return true;
      }
      else{
          return false;
      }
  }
	public function getDataWhere($table,$where)
	{
		$query = $this->db->select("*")->from($table)->where($where)->get()->row();
		// echo $this->db->last_query();exit;
		return $query;
	}
	public function getDataWhereMore($table, $where){
      $this->db->select('*');
      $this->db->from($table);
      $this->db->where($where);
     $query = $this->db->get();
     if($query){
        return $query->result();
     }else{
        return false;
     }
    }

	public function getRecordCountWhere($table,$where)
    {
     	$query = $this->db->select('*')->from($table)->where($where)->get();
		if($query){
			return $query->num_rows();
		}else{
			return false;
		}
	}
  public function getQueryData($query)
  {
    $sql = $this->db->query($query);
    // echo $this->db->last_query();exit;
    return $sql->result();
  }


	public function insertData($table,$data)
	{
		$query = $this->db->insert($table,$data);
		return true;
	}

	public function updateData($table,$where,$data)
	{
		$query = $this->db->where($where)->update($table,$data);
		// echo $this->db->last_query();exit;
		return true;
	}

	public function deleteData($table,$where)
	{
		$query = $this->db->where($where)->delete($table);
		// echo $this->db->last_query();exit;
		return true;
	}

	public function data_exists($where,$table)
	{
		$this->db->where($where);
		$query=$this->db->get($table);	
		return $query->row();
	}

	public function insertImages($table,$data){
        // print_r($data);exit;
        $insert = $this->db->insert($table,$data);
        return $insert?true:false;
    }
	public function updateImages($table,$where,$data){
        // print_r($data);exit;
        $query = $this->db->where($where)->update($table,$data);
        return $query?true:false;
    }


public function joinQueryData($id){
  $this->db->select('*')
     ->from('tbl_gallery as g')
     ->where('g.Product_Shape', $id)
     ->join('tbl_shape as s', 's.id = g.Product_Shape', 'INNER')
     ->get();
}








    // this is newsletter

    public function getColumnsWhere($column,$table,$where)
    {
      $result = $this->db->select($column)->from($table)->where($where)->get()->row();
      return $result;
    }

    public function qaCountQuery($query)
    {
    $sql = $this->db->query($query)->row();
    // echo $this->db->last_query();exit;
    return $sql;
    }

 public function sendMail($sender,$reciever,$postData)
      {
        // return true;
        // echo "<pre>";
        // print_r($sender);
        // print_r($reciever);
        // print_r($postData);
        // exit;



        $config['mailtype'] = 'html'; // or html
        $this->email->initialize($config);

        $message = $postData['message'];

          // echo $message;exit;  
            
        $this->email->from($sender->GreendaleEmail, $sender->siteTitle);
            $this->email->to($reciever); 
        // $this->email->to("bcv0505@gmail.com"); 
        $this->email->subject($postData['subject']);
        $this->email->message($message);  

        $data=$this->email->send();
          if($data){
          // echo "success";exit;
            return true;
            
          }else{
          // echo "Fail";exit;
            return false;
          }
          
        }
        // this is newsletter
        public function sendNewsletter($value)
        { 

        // print_r($value);exit;

        $email = $value['email'];


        // $toEmail = 'greendale2014@gmail.com';

        $config['mailtype'] = 'html'; // or html
        $this->email->initialize($config);

        $message = '<body style="margin: 0px;"><h1 style="color:blue;">Best Medical Supply</h1><h3 style="color:green;">YOU HAVE SUCCESSFULLY SUBSCRIBED TO THE NEWSLETTER</h3></body>';
        $this->email->from('info@bestmedicalsupplyga.com','Best Medical Supply');

        $this->email->to($email); 


        $this->email->subject('Best Medical Supply');
        $this->email->message($message);  

        $data = $this->email->send();

        // print_r($data);exit;
        if($data){
        return true;
        }else{
        return false;
        }

        }
        public function sendContactMail($value)
        { 

        // print_r($value);exit;

        $email = $value['email'];
        $subject = $value['subject'];
        $Comment = $value['Comment'];
        $name = $value['name'];

        $emailArr = [$email,'info@bestmedicalsupplyga.com'];


        $mail_count= count($emailArr);
        // echo $mail_count;exit;

        // $toEmail = 'greendale2014@gmail.com';

        $config['mailtype'] = 'html'; // or html
        $this->email->initialize($config);

        $message = '<body style="margin: 0px;"><h1 style="color:blue;">Best Medical Supply</h1><h3 style="color:green;">YOU HAVE SUCCESSFULLY SUBMITED DATA TO Best Medical Supply</h3><h3>Name : '.$name.'</h3><h3>Email : '.$email.'</h3><h3>Subject : '.$subject.'</h3><h3>Comment :'.$Comment.'<h3></body>';


        // print_r($data);exit;
        // if($data){
        //   return true;
        // }else{
        //   return false;
        // }

        if($mail_count > 0){
        for($i=0;$i<$mail_count;$i++)
        {
        $mail_id = TRIM($emailArr[$i]);

        // echo $mail_id;exit;
        // $this->email->from('1@gempaversystems.com','Gempaversystems');
        $this->email->from('info@bestmedicalsupplyga.com','Best Medical Supply');
        $this->email->to($mail_id); 
        $this->email->subject('Best Medical Supply');
        $this->email->message($message);  
        $this->email->send();
        $this->email->clear();
        }
        return true;
        }else{
        return false;
        }

        }


    public function sendlink($value)
      {
          // print_r( $value);exit;

      	$uname =$value['username'];
      	$email =$value['email'];
      	$subject =$value['subject'];
      	$mobile =$value['mobile'];
      	$message1 =$value['message'];
      	$talk =$value['talk'];
        // $toEmail = 'pavan.prasad512@gmail.com';
      	$toEmail = 'greendale2014@gmail.com';
          // print_r( $value);exit;
      	
          $config['mailtype'] = 'html'; // or html
          $this->email->initialize($config);

            $message = '<body style="margin: 0px;">

<div style="background:url(http://96.125.162.228/Greendale/assets/images/emailbgimage.png) top center no-repeat; text-align:center;background-size: cover;height:auto;display: inline-block;float: left;">
<div style="display:inline-block; width:100%; text-align:center;">
	<img src="http://96.125.162.228/Greendale/assets/images/emaillogo.png" alt="logo"  style="max-width: 100%;height: auto;">
</div>
<div style="display: inline-block;width: 60%;text-align: left;">
<h4 style="float: left;display: inline-block;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 100%;text-align: left;margin-bottom: 0px;">Dear Customer </h4>
<h5 style="float: left;display: inline-block;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 100%;text-align: left;">Greendale  – The complete international, is located in a sprawling 15-Acre lush green campus just 5km away from the city. This gives our children the perfect amalgam of ambience and serenity. We want our students to relish all that school has to offer so that the student leaves us as a confident, positive young individual truly prepared for there future. We expect each student to be a responsible and considerate global citizen who is outward looking, courageous and compassionate. We support them in being aspirational and in developing their interests and talents whilst learning to achieve balance in there life.</h5>
</div>
<div style="display: inline-block;width: 85%;position: relative !important;text-align: left;">
	
 

    <table style="width: 100%;">
      <tbody>
      <tr>
        <th style="width: 150px; vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Name :-</strong></th>
        <td><p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$uname.'</p></td>
      </tr>

<tr>
        <th style="width: 150px; vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Email :-</strong></th>
        <td> <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;"><a href="#" style="color: #1e1e1e;">'.$email.'</a></p></td>
      </tr>

 
      <tr>
        <th style="width: 150px; vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Phone No :-</strong></th>
        <td><p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$mobile.'</p> </td>
      </tr>


      <tr>
        <th style="width: 150px; vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Message :-</strong></th>
        <td> <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$message1.'</p> </td>
      </tr>
       
 
    


      

    </tbody>

    </table>    
        
   
    
    <div style="display: inline-block;position: absolute !important;top: 0px;right: 0px;" >
    	<img src="http://96.125.162.228/Greendale/assets/images/emailchating.png" alt="" style="max-width: 100%;height: auto;">
    </div>
    
    </div>
    
  
    
   <div style="display: inline-block;width: 60%;text-align: left;margin-top: 20px;" > 
    <p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight:600;color: #666;" ><a href="#"  style="color:#20a73e;font-weight:600;">Greendale</a> – The Complete International School</p>
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight:400;color: #666;">Opp International Cricket Stadium, Vuda 100ft Road,</p>
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight:400;color: #666;">Towards Shriram Properties, Madhurawada, Vizag – 41</p>
</div>
<div style="display: inline-block;width: 60%;margin-top: 5px;">
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight: 300;color: #666;">Phone: +91 89788 85500, +91  891 6066690</p>
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight: 300;color: #666;">Email: greendale2014@gmail.com</p>
</div>
    
   <div style="display:inline-block; float:left; width:100%; text-align:center;margin-top: 20px;margin-bottom: 20px;">
      <p style="display: inline-block;margin-bottom:0px;font-size: 14px;font-weight: 400;color: #666;padding: 0px 30px;">Copyrights © 2018. <a href="#"  style="color:#666;">Greendale.</a> All rights reserved.</p>
   </div> 
    
    
    
</div>




</body>';

        // print_r($message);exit;

                    $this->email->from($email, 'Greendale');
                    
                    $this->email->to($toEmail); 
                    

                    $this->email->subject('GET IN TOUCH WITH US');
                    $this->email->message($message);  

                    $data=$this->email->send();

                    // print_r($data);exit;
                      if($data){
                        return true;
                        // $this->session->set_flashdata('success',"Please check your mail for reset link");
                        // redirect('admin');
                      }else{
                        return false;
                      }
    }

    public function sendlinkEnquery($value)
    {	

    	// print_r($value);exit;

    	$parent = $value['parent'];
    	$student = $value['student'];
    	$email = $value['email'];
    	$grade = $value['grade'];
    	$address = $value['address'];
    	$pinCode = $value['pinCode'];
    	$academic_year = $value['academic_year'];
    	$date_of_birth = $value['date_of_birth'];
    	$mobile_number = $value['mobile_number'];
    	$occupation = $value['occupation'];
    	$city = $value['city'];

    	$toEmail = 'greendale2014@gmail.com';

    	$config['mailtype'] = 'html'; // or html
          $this->email->initialize($config);

    	$message = '<body style="margin: 0px;">

<div style="background:url(http://96.125.162.228/Greendale/assets/images/emailbgimage.png) top center no-repeat; text-align:center;background-size: cover;height:auto;display: inline-block;float: left;">
<div style="display:inline-block; width:100%; text-align:center;">
	<img src="http://96.125.162.228/Greendale/assets/images/emaillogo.png" alt="logo"  style="max-width: 100%;height: auto;">
</div>
<div style="display: inline-block;width: 60%;text-align: left;">
<h4 style="float: left;display: inline-block;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 100%;text-align: left;margin-bottom: 0px;">Dear Customer </h4>
<h5 style="float: left;display: inline-block;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 100%;text-align: left;">Greendale  – The complete international, is located in a sprawling 15-Acre lush green campus just 5km away from the city. This gives our children the perfect amalgam of ambience and serenity. We want our students to relish all that school has to offer so that the student leaves us as a confident, positive young individual truly prepared for there future. We expect each student to be a responsible and considerate global citizen who is outward looking, courageous and compassionate. We support them in being aspirational and in developing their interests and talents whilst learning to achieve balance in there life.</h5>
</div>
<div style="display: inline-block;width: 60%;position: relative;text-align: left;">
	
    <table style="width: 100%;">
      <tbody>
      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Name of the Parent :-</strong></th>
        <td><p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$parent.'</p></td>
      </tr>

<tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Email :-</strong></th>
        <td> <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;"><a href="#" style="color: #1e1e1e;">'.$email.'</a></p></td>
      </tr>

      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Name of the Student :-</strong></th>
        <td>   <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$student.'</p> </td>
      </tr>



      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Applying for Grade :-</strong></th>
        <td>    <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$grade.'</p> </td>
      </tr>

 
      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;" >Address :-</strong></th>
        <td><p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$address.'</p> </td>
      </tr>

 
    
   

      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Pin code :-</strong></th>
        <td>  <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$pinCode.'</p></td>
      </tr>

 
        
       


      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Occupation :-</strong></th>
        <td> <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$occupation.'</p> </td>
      </tr>


  
    
 
      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Mobile Number :-</strong></th>
        <td><p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$mobile_number.'</p> </td>
      </tr>


       
 
    


      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;"> Date Of Birth :-</strong></th>
        <td><p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$date_of_birth.'</p> </td>
      </tr>

      <tr>
        <th style="width: 150px;vertical-align: top;"><strong style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width: 240px;text-align: right;">Applying for academic Year :-</strong></th>
        <td>  <p style="float: left;display: inline-block;padding: 5px;font-size: 16px;font-weight: 400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$academic_year.'</p></td>
      </tr>

    
   

      <tr>
        <th style="width: 150px;vertical-align: top;"><strong  style="float: left;display:inline-block;padding: 5px;font-size: 16px;font-weight: bold;color: #1e1e1e;min-width:240px;text-align: right;">City :-</strong></th>
        <td> <p style="float: left;display: inline-block;padding: 5px;font-size:16px;font-weight:400;color: #1e1e1e;width: 55%;text-align: left;margin-bottom: 0px;margin-top: 0px;">'.$city.'</p> </td>
      </tr>


    </tbody>

    </table>    
        
   
    
    <div style="display: inline-block;position:absolute;top:0px;right:0px;" >
    	<img src="http://96.125.162.228/Greendale/assets/images/emailchating-equiy.png" alt="" style="max-width: 100%;height: auto;">
    </div>
    
    </div>
  
   <div style="display: inline-block;width: 60%;text-align: left;margin-top: 20px;" > 
    <p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight:600;color: #666;" ><a href="#"  style="color:#20a73e;font-weight:600;">Greendale</a> – The Complete International School</p>
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight:400;color: #666;">Opp International Cricket Stadium, Vuda 100ft Road,</p>
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight:400;color: #666;">Towards Shriram Properties, Madhurawada, Vizag – 41</p>
</div>
<div style="display: inline-block;width: 60%;margin-top: 5px;">
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight: 300;color: #666;">Phone: +91 89788 85500, +91  891 6066690</p>
<p style="display: inline-block;width: 100%;text-align: left; margin-bottom:0px;font-size: 14px;font-weight: 300;color: #666;">Email: greendale2014@gmail.com</p>
</div>
    
   <div style="display:inline-block; float:left; width:100%; text-align:center;margin-top: 20px;margin-bottom: 20px;">
      <p style="display: inline-block;margin-bottom:0px;font-size: 14px;font-weight: 400;color: #666;padding: 0px 30px;">Copyrights © 2018. <a href="#"  style="color:#666;">Greendale.</a> All rights reserved.</p>
   </div> 
    
    
    
</div>




</body>';
                    $this->email->from($email,'Greendale');
                    
                    $this->email->to($toEmail); 
                    

                    $this->email->subject('ONLINE ENQUIRY NOTIFICATION');
                    $this->email->message($message);  

                    $data = $this->email->send();

                    // print_r($data);exit;
                      if($data){
                        return true;
                      }else{
                        return false;
                      }
                    
    }
}	

?>