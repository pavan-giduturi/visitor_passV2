<?php 

/**
 * 
 */
class Front extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		date_default_timezone_set('Asia/Calcutta');
		$pdate = date('d-m-Y');

		
			$db_find = $this->db->database;

		if(!empty($db_find)){

		$sql = "SELECT * FROM tbl_passes where PDate='".$pdate."' ORDER BY id DESC LIMIT 1";
		$data['row'] = $this->Main_Model->getQueryData($sql);
		// print_r($data['row']);exit;
		// $data['site'] = $this->Main_Model->getSite();
		$this->load->view('front/header',$data);
		$this->load->view('front/index',$data);
		$this->load->view('front/footer',$data);
		// echo "success";
		}else{
		$this->load->view('front/project_setup');			
		}
	}

	function setupDatabase(){
			

		
			if ($conn->query($create_db_query) === TRUE) {
			// $dbname = $this->db->database;
				$dbname = $database;
				$connected = new mysqli($hostname, $username, $password, $dbname);
				$admin_crate = "CREATE TABLE `tbl_admin` (
				`id` int(11) NOT NULL,
				`firstName` varchar(100) NOT NULL,
				`lastName` varchar(100) NOT NULL,
				`profileImage` varchar(50) NOT NULL,
				`email` varchar(100) NOT NULL,
				`password` varchar(255) NOT NULL,
				`phoneNumber` bigint(15) NOT NULL,
				`country` tinyint(3) NOT NULL,
				`state` tinyint(3) NOT NULL,
				`city` tinyint(3) NOT NULL,
				`zipcode` int(11) NOT NULL,
				`roleType` varchar(250) NOT NULL,
				`collegeId` tinyint(2) NOT NULL,
				`status` tinyint(2) NOT NULL,
				`createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				$connected->query($admin_crate);

				$pass_table_create = "CREATE TABLE `tbl_passes` (
				`id` int(11) NOT NULL,
				`SLNO` varchar(250) NOT NULL,
				`pass_no` varchar(250) NOT NULL,
				`PDate` varchar(250) NOT NULL,
				`Name` varchar(250) NOT NULL,
				`Designation` varchar(250) NOT NULL,
				`Floor` varchar(250) NOT NULL,
				`Add_content` text NOT NULL,
				`ID_Proof` varchar(250) NOT NULL,
				`Phone` varchar(250) NOT NULL,
				`Person_to_be_visited` text NOT NULL,
				`part_b_Designation` varchar(250) NOT NULL,
				`Purpose_of_visit` varchar(250) NOT NULL,
				`in_time` varchar(250) NOT NULL,
				`out_time` varchar(250) NOT NULL,
				`Remarks` text NOT NULL,
				`profile_image` varchar(250) NOT NULL,
				`status` tinyint(4) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				$connected->query($pass_table_create);


				$sitesettings_create = "CREATE TABLE `tbl_site_settings` (
				`id` tinyint(3) NOT NULL,
				`siteTitle` varchar(100) NOT NULL,
				`siteLogo` varchar(255) NOT NULL,
				`siteAddress` text NOT NULL,
				`siteEmail` text NOT NULL,
				`password` varchar(250) NOT NULL,
				`siteFacebook` varchar(100) NOT NULL,
				`siteTwitter` varchar(100) NOT NULL,
				`siteInstagram` varchar(100) NOT NULL,
				`siteYoutube` varchar(100) NOT NULL,
				`googleplus` varchar(250) NOT NULL,
				`linkedin` varchar(250) NOT NULL,
				`vk` varchar(250) NOT NULL,
				`siteFooter` varchar(255) NOT NULL,
				`Map` text NOT NULL,
				`mobile` varchar(50) NOT NULL,
				`status` tinyint(2) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				if ($connected->query($sitesettings_create) === TRUE) {

					redirect('');
				}

		}else{
			echo "installation is done ";

		}
	}

	

	public function formData()
	{
		
		// print_r($this->input->post());exit;
		$SLNO = $this->input->post('SLNO');
		$Name = $this->input->post('Name');
		$Phone = $this->input->post('Phone');
		$Designation = $this->input->post('Designation');
		$Floor = $this->input->post('Floor');
		$Add_content = $this->input->post('Add_content');
		$ID_Proof = $this->input->post('ID_Proof');
		$Person_to_be_visited = $this->input->post('Person_to_be_visited');
		$part_b_Designation = $this->input->post('part_b_Designation');
		$Purpose_of_visit = $this->input->post('Purpose_of_visit');
		$in_time = $this->input->post('in_time');
		$out_time = $this->input->post('out_time');
		$Remarks = $this->input->post('Remarks');
		$profile_image = $this->input->post('profile_image');
		$PDate = $this->input->post('PDate');

		$data = array(
			'SLNO'=>$SLNO,
			'Name'=>$Name,
			'Phone'=>$Phone,
			'Designation'=>$Designation,
			'Floor'=>$Floor,
			'Add_content'=>$Add_content,
			'ID_Proof'=>$ID_Proof,
			'Person_to_be_visited'=>$Person_to_be_visited,
			'part_b_Designation'=>$part_b_Designation,
			'Purpose_of_visit'=>$Purpose_of_visit,
			'in_time'=>$in_time,
			'out_time'=>$out_time,
			'Remarks'=>$Remarks,
			'profile_image'=>$profile_image,
			'PDate'=>$PDate
			
		);
		// print_r($data);exit;

		$result = $this->Main_Model->insertData('tbl_passes',$data);

		if($result){
			// $this->Main_Model->sendContactMail($data);
			$this->session->set_userdata('success','successfully submited.');
			redirect('success');
		}else{
			$this->session->set_userdata('failure','failed submited data.');
			redirect('');

		}
	}
	

	public function successTemplate()
	{
		
		$this->load->view('front/success-thank-you');
	}
	
	

	


	

}
