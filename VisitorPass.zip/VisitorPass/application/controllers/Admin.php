<?php 

/**
 * 
 */
class Admin extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data['site'] = $this->Main_Model->getSite();
		// print_r($data['site']);exit;
		
		$this->load->view('admin/login',$data);
		
	}

	public function Signup()
	{
		$data['site'] = $this->Main_Model->getSite();
		
		$this->load->view('admin/signup',$data);
		
	}

	public function adminLoginForm()
	{
		// print_r($this->input->post());exit;
		$email = $this->input->post('email');
		$password = md5($this->input->post('password'));

		$data = array('email'=>$email,'password'=>$password);

		$login_check = $this->Main_Model->getDataWhere('tbl_admin',$data);

		if($login_check->id ==1){

			$userdata = array(
				'id'=>$login_check->id,
				'firstName'=>$login_check->firstName,
				'email'=>$login_check->email,
			);
			$this->session->set_userdata($userdata);
			$this->session->set_flashdata('success','Successfully logged in');
			redirect('admin-dashboard');
		}else{
			$this->session->set_flashdata('error','No details found. Please check once again');
			redirect('admin');

		}	
	}

	public function adminSignupForm()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$email_exist=$this->Main_Model->mail_exists($email);
		if($email_exist){
		$data=array();
		$this->session->set_flashdata('error', 'Email Existed');
		redirect('admin-signup');
		}
		$data = array('email'=>$email,'password'=>md5($password));

		$result = $this->Main_Model->insertData('tbl_admin',$data);
		if($result){
		$this->session->set_flashdata('success', 'signup success');
			redirect('admin');
		}else{
		$this->session->set_flashdata('error', 'Email Existed');
			redirect('admin');
		}
	}

	public function adminDashboard()
	{
		if(!empty($this->session->userdata('id'))){
		$data['site'] = $this->Main_Model->getSite();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/dashboard',$data);
		$this->load->view('admin/footer',$data);
		}else{
			redirect('admin');
		}
	}

	public function adminLogout()
	{
		if(!empty($this->session->userdata('id'))){
			$userdata = array(
				'id'=>'',
				'firstName'=>'',
				'email'=>'',
			);
			$this->session->set_userdata($userdata);
			redirect('admin');
		}else{
			redirect('admin');
		}
	}

		public function adminSiteSettingsPage()
		{
			if(!empty($this->session->userdata('id'))){
			$data['site'] = $this->Main_Model->getSite();
			$data['admin']= $this->Main_Model->getDataWhere('tbl_site_settings',array('id'=>$this->session->userdata('id')));
			$this->session->set_flashdata('error','Please Login');
			$this->load->view('admin/header',$data);
			$this->load->view('admin/siteSettings',$data);
			$this->load->view('admin/footer',$data);
			}else{
			redirect('admin');
			}
		}

		public function adminSiteAdd()
		{
			// print_r($this->input->post());exit;
			if($this->session->userdata('id')==""){
			$this->session->set_flashdata('error','Please Login');
			redirect('admin');
			}	
			$image = $_FILES['siteLogo']['name'];
			if($image){
			$newImage = time().'_'.$image;
			$imageUpload=$this->uploadImage($newImage,'siteLogo','site');
			if($imageUpload){
			$imageUpload=$newImage;
			}else{
			$this->session->set_flashdata('error', 'Image is not Upload');
			redirect('');
			}
			}else{
			$imageUpload=$this->input->post('hiddensiteLogo');
			}


			// echo $imageUpload;exit;
			$where = array('id'=>$this->input->post('id'));
			$data = array(
			'siteTitle'=>$this->input->post('siteTitle'), 
			'siteAddress'=>$this->input->post('siteAddress'), 
			'siteLogo'=>$imageUpload, 
			// 'siteFacebook'=>$this->input->post('siteFacebook'), 
			// 'siteTwitter'=>$this->input->post('siteTwitter'), 
			// 'siteInstagram'=>$this->input->post('siteInstagram'), 
			'siteFooter'=>$this->input->post('siteFooter'), 
			// 'siteYoutube'=>$this->input->post('siteYoutube'), 
			// 'vk'=>$this->input->post('vk'), 
			// 'Map'=>$this->input->post('Map'), 
			// 'linkedin'=>$this->input->post('linkedin'), 
			// 'googleplus'=>$this->input->post('googleplus'), 
			'mobile'=>$this->input->post('mobile'), 
			'siteEmail'=>$this->input->post('siteEmail'), 
			// 'siteYoutube'=>$this->input->post('siteYoutube'), 
			);
			// print_r($data);exit;
			$result=$this->Main_Model->insertData('tbl_site_settings',$data);
			if($result){
			$this->session->set_flashdata('success', 'Site updated successfully');
			redirect('admin-site-settings-page');
			}else{
			$this->session->set_flashdata('failure', 'Site updation failed');
			redirect('admin-site-settings-page');
			}
		}


		public function adminSiteUpdate()
		{
			// print_r($this->input->post());exit;
			if($this->session->userdata('id')==""){
			$this->session->set_flashdata('error','Please Login');
			redirect('admin');
			}	
			$image = $_FILES['siteLogo']['name'];
			if($image){
			$newImage = time().'_'.$image;
			$imageUpload=$this->uploadImage($newImage,'siteLogo','site');
			if($imageUpload){
			$imageUpload=$newImage;
			}else{
			$this->session->set_flashdata('error', 'Image is not Upload');
			redirect('');
			}
			}else{
			$imageUpload=$this->input->post('hiddensiteLogo');
			}


			// echo $imageUpload;exit;
			$where = array('id'=>$this->input->post('id'));
			$data = array(
			'siteTitle'=>$this->input->post('siteTitle'), 
			'siteAddress'=>$this->input->post('siteAddress'), 
			'siteLogo'=>$imageUpload, 
			// 'siteFacebook'=>$this->input->post('siteFacebook'), 
			// 'siteTwitter'=>$this->input->post('siteTwitter'), 
			// 'siteInstagram'=>$this->input->post('siteInstagram'), 
			'siteFooter'=>$this->input->post('siteFooter'), 
			// 'siteYoutube'=>$this->input->post('siteYoutube'), 
			// 'vk'=>$this->input->post('vk'), 
			// 'Map'=>$this->input->post('Map'), 
			// 'linkedin'=>$this->input->post('linkedin'), 
			// 'googleplus'=>$this->input->post('googleplus'), 
			'mobile'=>$this->input->post('mobile'), 
			'siteEmail'=>$this->input->post('siteEmail'), 
			// 'siteYoutube'=>$this->input->post('siteYoutube'), 
			);
			// print_r($data);exit;
			$result=$this->Main_Model->updateData('tbl_site_settings',$where,$data);
			if($result){
			$this->session->set_flashdata('success', 'Site updated successfully');
			redirect('admin-site-settings-page');
			}else{
			$this->session->set_flashdata('failure', 'Site updation failed');
			redirect('admin-site-settings-page');
			}
		}




// records  start

	public function adminRecordsPage()
	{
		$data = array();
		if($this->session->userdata('id')){
			$data['records'] = $this->Main_Model->getData('tbl_passes');
			$data['site'] = $this->Main_Model->getSite();
			
            $data['admin']= $this->Main_Model->getDataWhere('tbl_admin',array('id'=>$this->session->userdata('id')));
			$this->load->view('admin/header',$data);
			$this->load->view('admin/shop/dashboard',$data);
			$this->load->view('admin/footer',$data);
		}else{
			$this->session->set_flashdata('error','Please Login');
			redirect('admin');
		}
	}
	public function visitorFromToDate()
	{
		$data = array();
		if($this->session->userdata('id')){
			$from = $this->input->post('from');
			$to = $this->input->post('to');
			$query = "select * from tbl_passes WHERE STR_TO_DATE(PDate, '%d-%m-%Y')  BETWEEN '".$from."' AND '".$to."'";

			$data['records'] = $this->Main_Model->getQueryData($query);
			$data['site'] = $this->Main_Model->getSite();
			
            $data['admin']= $this->Main_Model->getDataWhere('tbl_admin',array('id'=>$this->session->userdata('id')));
			$this->load->view('admin/header',$data);
			$this->load->view('admin/shop/dashboard',$data);
			$this->load->view('admin/footer',$data);
		}else{
			$this->session->set_flashdata('error','Please Login');
			redirect('admin');
		}
	}

	public function visitorDateFilter()
	{
		$data = array();
		if($this->session->userdata('id')){
			$orgDate = $this->input->post('singleDate');
			$today = date("d-m-Y", strtotime($orgDate));  
			$query = "select * from tbl_passes WHERE PDate='".$today."'";

			$data['records'] = $this->Main_Model->getQueryData($query);
			$data['site'] = $this->Main_Model->getSite();
			
            $data['admin']= $this->Main_Model->getDataWhere('tbl_admin',array('id'=>$this->session->userdata('id')));
			$this->load->view('admin/header',$data);
			$this->load->view('admin/shop/dashboard',$data);
			$this->load->view('admin/footer',$data);
		}else{
			$this->session->set_flashdata('error','Please Login');
			redirect('admin');
		}
	}
	// public function adminRecordsAddPage()
	// {
	// // print_r($this->session->userdata('id'));exit;
	// if($this->session->userdata('id')){
	// 	$data=array();
	// 	$id=$this->uri->segment(2);
	// 	// echo $id;exit;
	// 	$table="tbl_passes";
	// 	$where = array('id' =>$id);
	// 	$data['editContent'] = $this->Main_Model->getDataWhere($table,$where);
 //   		$data['site'] = $this->Main_Model->getSite();
 //     	$data['admin']= $this->Main_Model->getDataWhere('tbl_admin',array('id'=>$this->session->userdata('id')));
     	
	// 	$this->load->view('admin/header',$data);
	// 	$this->load->view('admin/shop/shopAdd',$data);
	// 	$this->load->view('admin/footer',$data);
	// }else{
	// 	$this->session->set_flashdata('error','Please Login');
	// 	redirect('admin');
	// }
	// }
	// public function adminShopAdd()
	// {
	// 	if($this->session->userdata('id')){
	// 		$image= $_FILES['productImage']['name'];
	// 		// echo $image;exit;
	// 		if($image){
	// 			$newImage = time().'_'.$image;
	// 			$imageUpload=$this->uploadImage($newImage,'productImage','shop');
	// 		// print_r($imageUpload);exit;
	// 			if($imageUpload){
	// 				$imageUpload=$newImage;
	// 			}else{
	// 				$this->session->set_flashdata('error', 'Image is not Upload');
	// 				redirect('admin-shop-page');
	// 			}
	// 		}else{
	// 			$imageUpload="No image";
	// 		}
	// 		// echo $imageUpload;exit;
	// 		// $collegeId=$this->session->userdata('collegeId');
	// 		$productTitle=$this->input->post('productTitle');
	// 		// $productPrice=$this->input->post('productPrice');
	// 		$buyNowLink=$this->input->post('buyNowLink');
	// 		$status=$this->input->post('status');
	// 		$data = array(
	// 			'productTitle' =>$productTitle , 
	// 			'productImage' =>$imageUpload , 
	// 			// 'productPrice' =>$productPrice , 
	// 			'buyNowLink' =>$buyNowLink , 
	// 			'status' =>$status
	// 			);
	// 		// print_r($data);exit;
	// 		$result=$this->Main_Model->insertData('tbl_shop',$data);
	// 		if($result){
	// 			$this->session->set_flashdata('success', 'banner added successfully');
	// 			redirect('admin-shop-page');
	// 		}else{
	// 			$this->session->set_flashdata('failure', 'banner adding failed');
	// 			redirect('admin-shop-add-page');
	// 		}
	// 	}else{
	// 		$this->session->set_flashdata('error','Please Login');
	// 		redirect('admin');
	// 	}
	// }
	// 	public function adminShopUpdate()
	// 	{

	// 		// print_r($this->input->post());exit;
	// 		if($this->session->userdata('id')==""){
	// 			$this->session->set_flashdata('error','Please Login');
	// 			redirect('admin');
	// 		}	
	// 		$image = $_FILES['productImage']['name'];
	// 		if($image){
	// 			$newImage = time().'_'.$image;
	// 			$imageUpload=$this->uploadImage($newImage,'productImage','shop');
	// 			if($imageUpload){
	// 				$imageUpload=$newImage;
	// 			}else{
	// 				$this->session->set_flashdata('error', 'Image is not Upload');
	// 				redirect('admin-shop-add');
	// 			}
	// 		}else{
	// 			$imageUpload=$this->input->post('hiddenproductImage');
	// 		}
	// 		// echo $imageUpload;exit;
	// 		// $collegeId=$this->session->userdata('collegeId');
	// 		$productTitle=$this->input->post('productTitle');
	// 		// $productPrice=$this->input->post('productPrice');
	// 		$buyNowLink=$this->input->post('buyNowLink');
	// 		$status=$this->input->post('status');
	// 		$data = array(
	// 			// 'collegeId' =>$collegeId, 
	// 			'productTitle' =>$productTitle , 
	// 			'productImage' =>$imageUpload , 
	// 			// 'productPrice' =>$productPrice , 
	// 			'buyNowLink' =>$buyNowLink , 
	// 			'status' =>$status
	// 		);
	// 		// print_r($data);exit;
	// 		$table="tbl_shop";
	// 		$where = array('id'=>$this->input->post('id'));
	// 		$result=$this->Main_Model->updateData('tbl_shop',$where,$data);
			
	// 		$data = $this->Main_Model->getDataWhere($table,$where);
	// 		if($result){
	// 			$this->session->set_flashdata('success', 'Product updated successfully');
	// 			redirect('admin-shop-page');
	// 		}else{
	// 			$this->session->set_flashdata('failure', 'Product updation failed');
	// 			redirect('admin-shop-page');
	// 		}
	// 	}
		public function adminShopDelete()
		{
			if($this->session->userdata('id')==""){
				$this->session->set_flashdata('error','Please Login');
				redirect('admin');
			}
			$result=$this->Main_Model->deleteData('tbl_passes',array('id'=>$this->uri->segment(2)));
			if($result){
				$this->session->set_flashdata('success', 'visitor Deleted successfully');
				redirect('admin-records-page');
			}else{
				$this->session->set_flashdata('failure', 'visitor deletion failed');
				redirect('admin-records-page');
			}
		}



		public function uploadImage($image,$fieldname,$folder)
		{
		// echo $image.",".$fieldname.",".$folder;exit;
		$config = array(
		'file_name'=>$image,
		'upload_path' => "./uploads/".$folder."/",
		'allowed_types' => "gif|jpg|png|jpeg|pdf|mp4",
		'overwrite' => TRUE,
		// 'max_size' => '102400'
		);
		$this->load->library('upload',$config);
		if($this->upload->do_upload($fieldname))
		{
		$result=$this->upload->data();
		// echo "suc";exit;
		// print_r($result);
		// die('success');
		return true;
		}else{
		// echo "Fail";exit;
		$data=$this->upload->display_errors();
		// print_r($data);
		// die('failed');
		return false;
		}
		}

}

?>