<?php
if(!empty($row)){
            $snval = $row[0]->SLNO + 1;
            }else{
            $snval = 1;

            }

            $barcodeslno = time()."CBIC".$snval;

            $pbc = explode('CBIC', $barcodeslno);
 ?>
<body>
<div class="container-fluid layer1">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6 col-md-offset-6 col-sm-12 col-lg-6 col-md-offset-6 text-right layer2a" id="exitdata">       
          <div class="submitcb">
              <label><a href="javascript:void(0)" data-toggle="modal" data-target="#myModalEventStatus" class="btn btn-danger" id="exitbutton">Exit</a></label>
          </div>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12 col-md-12 col-sm-12 col-lg-12 layer1a">

        <div class="print_pass_id_normal" id="print_pass_id">
          <h1>Visitor Pass #<?php echo $snval; ?></h1>
        </div>
        <div class="logocb" id="print_logo_div">
          <a href="javascript:void(0)" id="print_logo_a"><img src="<?php echo base_url('assets'); ?>/images/logo-cbi.png" id="print_logo_a_img"></a>
        </div>

        <div class="heading-paracb" id="heading">
          <h1>Office of the principal commissioner of central tax</h1>
          <br>
          <h3>Hyderabad gst commissionerate</h3>
          <h3>gst bhavan, basheerbagh, hyderabad-500004</h3>
          <br>
          <h1>visitor's pass-gst bhavan, basheerbagh</h1>
        </div>
        <div class="heading-paracb" id="print_heading">
          <h6>Office of the principal commissioner of central tax</h6>
          <p>Hyderabad gst commissionerate</p>
          <p>gst bhavan, basheerbagh, hyderabad-500004</p>
        </div>

            <!-- <input type=button value="Save Snapshot" onClick="saveSnap()"> -->
            <!-- <input type=button value="Take Snapshot" onClick="take_snapshot()"> -->

      </div>
    </div>
  </div>
</div>

<div class="container-fluid layer2">
  <div class="container">
     <form action="<?php echo base_url('visitor-data'); ?>" method="post" enctype="multipart/form-data" onsubmit="return validation()">
    <div class="row" id="priter_row"> 
      
      <div class="col-xs-12 col-md-2 col-sm-12 col-lg-2 layer2a" id="SLNO">       
          <label><p>SLNO : <?php echo $snval; ?></p><input type="hidden" name="SLNO" value="<?php echo $snval; ?>" class="form-control"></label>
      </div>

      <!-- <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="pass_no">       
          <label><p>Pass No:</p><input type="text" name="pass_no" value="" class="form-control"></label>
      </div> -->

      <!-- <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a">       
         <label><p>Pass No: </p><input type="text" name="pass_no" value="" class="form-control"></label>
      </div> -->
      <div class="col-xs-12 col-md-3 col-sm-12 col-lg-3 layer2a" id="PDate">       
         <label><p>Date: </p><span><?php echo date('d-m-Y'); ?></span>
          <input type="hidden" name="PDate" value="<?php echo date('d-m-Y'); ?>" class="form-control">
        </label>
      </div>

      <div class="col-xs-12 col-md-3 col-sm-12 col-lg-3">       
              <!-- <div id="my_camera" onClick="take_snapshot()" class="profile"></div> -->
              <div id="my_camera" onClick="take_snapshot()" class="profile"></div>
      </div>



    </div>

     <div class="row" id="printer_names"> 
      <div class="col-xs-12 col-md-12 col-sm-12 col-lg-12 text-center layer2a" id="Part_A">       
          <h4>Part-A (Personal Details)</h4>
          <hr class="hr-bl">
      </div>
      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="print_p">       
         <label><p id="print_p_p">Ph.No :</p><input type="text" name="Phone" value="" class="form-control" id="Phone" required="required" onchange="phoneData(this.value),take_snapshot()"></label>
      </div>

       <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="print_n">       
          <label><p id="print_n_p">Name :</p><input type="text" name="Name" value="" class="form-control" id="name" required="required"></label>
      </div>
      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="Designation">       
         <label><p>Designation: </p><input type="text" name="Designation" value="" class="form-control" id="Designation_input"></label>
      </div>

      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="Add_content">       
          <label><p>Add:</p><textarea name="Add_content" class="form-control" id="Add_content_textarea"></textarea></label>
      </div>

      <div class="col-xs-12 col-md-4 col-md-offset-4 col-sm-12 col-lg-4 layer2a" id="id_proof">       
         <label><p>ID Proof:</p><input type="text" id="id_proof_text" name="ID_Proof" value="" class="form-control"></label>
      </div>
      
      
    </div>

     <div class="row"> 
      <div class="col-xs-12 col-md-12 col-sm-12 col-lg-12 text-center layer2a" id="part_b">       
          <h4>Part-B (Office Details)</h4>
          <hr class="hr-bl">
      </div>
     <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a">       
          <label><p id="print_visited_p">Person to be visited:</p><input type="text" name="Person_to_be_visited" value="" class="form-control" id="person"></label>
      </div>
      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a">       
         <label><p id="print_des_p">Designation: </p><input type="text" name="part_b_Designation" value="" class="form-control" id="part_b_Designation"></label>
      </div>
      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="floor">       
         <label><p id="print_floor">Floor: </p><input type="text" name="Floor" value="" class="form-control" id="input_floor"></label>
      </div>
      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="Purpose_of_visit">       
         <label><p>Purpose of visit:</p><input type="text" name="Purpose_of_visit" value="" class="form-control" id="Purpose" style="margin-left: 27px;"></label>
         
      </div>


      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="in_time">       
          <label class="tim-middle"><p>In Time:</p>
            <input type="hidden" name="in_time" value="<?php echo date('d-m-Y H:i:s'); ?>" class="form-control">
            <span><?php echo date('d-m-Y H:i:s'); ?></span>
          </label>
      </div>
      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="out_time">
         <label class="tim-middle"><p>Out Time:</p>
          <input type="hidden" name="out_time" value="" class="form-control">
        </label>
      </div>

      <div class="col-xs-12 col-md-4 col-sm-12 col-lg-4 layer2a" id="entry">       
          <label class="tim-middle"><p class="rigtside-textcb">Sign at the time of Entry</p></label>
      </div>
      <div class="col-xs-12 col-md-4 col-md-offset-4 col-sm-12 col-lg-4 layer2a" id="exit">       
          <label class="tim-middle"><p class="rigtside-textcb">Sign at the time of Exit</p></label>
      </div>
    </div>


         <div class="row"> 
      <div class="col-xs-12 col-md-12 col-sm-12 col-lg-12 text-center layer2a" id="part_c">       
          <h4>Part-C (Remarks)</h4>
          <hr class="hr-bl">
      </div>
     <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6 layer2a" id="Remarks">       
          <label><p>Remarks:</p> <textarea name="Remarks" class="form-control"></textarea></label>
      </div>
      <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6 layer2a" id="Issuing_Officer">       
         <label><p class="rigtside-textcb">Signature of Pass Issuing Officer</p></label>
      </div>

      <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6 layer2a" id="Signature_of_the_visitor">       
         <label><p>Signature of the visitor</p></label>
      </div> 
      <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6 layer2a" id="Signature_person_visited">       
         <label><p>Signature of the person visited</p></label>
      </div>
      <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6 layer2a" id="date_time">       
         <label><p>Date and Time : <?php echo date('d-m-Y H:i:s'); ?></p></label>
      </div>
      
      <input type="hidden" name="profile_image" value="" id="profile_data">

    </div>
      <div class="row">
        
      
      <div class="col-xs-12 col-md-12 col-sm-12 col-lg-12 text-center layer2a" id="submitdata">       
          <div class="submitcb">
              <label><input type="submit" name="submit" value="Print" class="btn btn-success"></label>
          </div>
      </div>

      </div>
      </form>
       <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6 layer2a" id="bar_image">       
          <label><p class="rigtside-textcb"><?php
         
          echo "<img alt='testing' src='".base_url('source/')."barcode.php?codetype=code128a&size=40&text=".$barcodeslno."&print=false'/>";
          
          ?></p></label>
      </div>
  </div>
</div>

