<?php 
// if(isset($_POST['SLNO']))
// {
//  $text=$_POST['SLNO'];
//  echo "<img alt='testing' src='barcode/barcode.php?codetype=Code39&size=40&text=".$text."&print=true'/>";
// }
?>
<!-- Modal start-->
                          <div class="modal fade" id="myModalEventStatus" role="dialog">
                          <div class="modal-dialog">

                          <!-- Modal content-->
                          <div class="modal-content">
                          <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Sign at the time of Exit</h4>
                          </div>
                          <div class="modal-body">
                          <form method="post" class="form-horizontal form-label-left input_mask" id="refEditModalFormEventStatus" action="<?php echo base_url('source'); ?>/update-exit-time.php">
                          <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12">Enter Barcode Id</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                          <input type="text" class="form-control" placeholder="Event Barcode" id="EventStatusId" name="barcodenumber" focus>
                          </div>
                          </div>
                         <!--  <p class="text-center">(or)</p>
                          <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone No </label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                          <input type="text" class="form-control" placeholder="Event Phone number" id="EventStatusId" name="phoneno">
                          </div>
                          </div> -->

                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                              <button type="submit" class="btn btn-success">Update</button>
                            </div>
                          </div>

                          </form>
                          </div>
                          <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                          </div>

                          </div>
                          </div>
                          <!-- Modal End-->

<script type="text/javascript" src="<?php echo base_url('assets'); ?>/webcamjs/webcam.min.js"></script>

<script>
$(document).keydown(function(e) {
    if (e.keyCode == 27) {
        $("#exitbutton").click()
    }   
});


$('#myModalEventStatus').on('shown.bs.modal', function () {
  $('#EventStatusId').focus()
});


function validation(){

  if($('#Phone').val() == ''){
    $('#Phone').focus();
    return false;
  }else{
    myfunction();
    window.print();
  }
}
  function phoneData(v){
    // alert(v);
    if (v.length == 0) {
        // document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              // alert(this.responseText);
              var x = JSON.parse(this.responseText);
              // alert(x);
              // alert(x['Name']);
              // console.log(x);
              $("#name").val(x["Name"]);
              $("#Designation_input").val(x["Designation"]);
              $("#Add_content_textarea").val(x["Add_content"]);
              $("#id_proof_text").val(x["ID_Proof"]);
            checkinputs();
            }
        };
        xmlhttp.open("GET", "<?php echo base_url('source'); ?>/get-data.php?phn=" + v, true);
        xmlhttp.send();
    }

      
  }

  function checkinputs(){
    if($("#name").val() == ''){
      $("#name").focus();
    }else if($("#Designation_input").val() == ''){
      $("#Designation_input").focus();
    }else if($("#Add_content_textarea").val()==''){
      $("#Add_content_textarea").focus();
    }else if($("#id_proof_text").val() ==''){
      $("#id_proof_text").focus();
    }else{
      $("#person").focus();
    }
  }

  function myfunction(){
    // alert();
    document.getElementById('heading').style.display="none";
    document.getElementById('print_heading').style.display="block";
    document.getElementById('SLNO').style.display="none";
    // document.getElementById('pass_no').style.display="none";
    document.getElementById('PDate').style.display="none";
    document.getElementById('Part_A').style.display="none";
    document.getElementById('Add_content').style.display="none";
    document.getElementById('id_proof').style.display="none";
    document.getElementById('entry').style.display="none";
    document.getElementById('exit').style.display="none";
    document.getElementById('in_time').style.display="none";
    document.getElementById('out_time').style.display="none";
    document.getElementById('Remarks').style.display="none";
    document.getElementById('part_c').style.display="none";
    document.getElementById('name').style.border="none";
    document.getElementById('Phone').style.border="none";
    document.getElementById('part_b_Designation').style.border="none";
    // document.getElementById('input_floor').style.border="none";
    document.getElementById('person').style.border="none";
    document.getElementById('Purpose').style.border="none";
    document.getElementById('Purpose_of_visit').style.display="none";
    document.getElementById('Issuing_Officer').style.display="none";
    document.getElementById('exitdata').style.display="none";
    document.getElementById('bar_image').style.display="block";
    document.getElementById('Designation').style.display="none";
    document.getElementById('submitdata').style.display="none";
    document.getElementById('part_b').style.display="none";
    document.getElementById('Signature_of_the_visitor').style.display="block";
    document.getElementById('Signature_person_visited').style.display="block";
    document.getElementById('date_time').style.display="block";

    $("#priter_row").addClass("print_row");
    $("#name").addClass("print_n_input");
    $("#Phone").addClass("print_p_input");
    $("#printer_names").addClass("printer_names");
    $("#print_n").addClass("print_n");
    $("#print_p").addClass("print_p");
    $("#print_logo_div").addClass("print_logo_div");
    $("#print_pass_id").addClass("print_pass_id");
    $("#print_logo_a").addClass("print_logo_a");
    $("#print_logo_a_img").addClass("print_logo_a_img");
    $("#print_n_p").addClass("print_n_p");
    $("#print_p_p").addClass("print_p_p");
    $("#print_visited_p").addClass("print_visited_p");
    $("#person").addClass("person");
    $("#print_des_p").addClass("print_des_p");
    $("#part_b_Designation").addClass("part_b_Designation");
    $("#print_floor").addClass("print_floor");
    $("#input_floor").addClass("input_floor");
    $('div').addClass('divcsss');


  }
</script>
<!-- Code to handle taking the snapshot and displaying it locally -->
<script language="JavaScript">

 // Configure a few settings and attach camera
 Webcam.set({
  width: 100,
  height: 100,
  image_format: 'jpeg',
  jpeg_quality: 90
 });
 Webcam.attach( '#my_camera' );

 // preload shutter audio clip
 var shutter = new Audio();
 shutter.autoplay = true;
 shutter.src = navigator.userAgent.match(/Firefox/) ? 'shutter.ogg' : 'shutter.mp3';

 var bt = true;
function take_snapshot() {
 // play sound effect
 if(bt == true){
 shutter.play();

 // take snapshot and get image data
 Webcam.snap( function(data_uri) {
 // display results in page
 document.getElementById('my_camera').innerHTML = 
  '<img id="imageprev" src="'+data_uri+'"/>';
 } );
 saveSnap();
 Webcam.reset();
  bt =false;
 }else{
  Webcam.set({
  width: 100,
  height: 100,
  image_format: 'jpeg',
  jpeg_quality: 90
 });
 Webcam.attach( '#my_camera' );
 // Webcam.reset();
 bt=true;

 }
}


function saveSnap(){
 // Get base64 value from <img id='imageprev'> source
 var base64image = document.getElementById("imageprev").src;

 Webcam.upload( base64image, '<?php echo base_url('source') ?>/upload.php', function(code, text) {
  console.log('Save successfully');
 document.getElementById('profile_data').value = text;
 document.getElementById('my_camera').innerHTML = 
  '<img src="<?php echo base_url('source'); ?>/upload/'+text+'"/>';
  // alert(text);
  //console.log(text);
 });

}
</script>

</body>
</html>