<?php 
date_default_timezone_set('Asia/Calcutta'); 
$pdate = date('d-m-Y');
?>
<?php 
// print_r($row);exit;
// $result = mysqli_query($connect, $sql);

            // $row = mysqli_fetch_assoc($result);

            if(!empty($row)){
            $snval = $row[0]->SLNO + 1;
            }else{
            $snval = 1;
            }

            // echo $snval;exit;

            // print_r($row);exit;

            $barcodeslno = time()."CBIC".$snval;

            $pbc = explode('CBIC', $barcodeslno);

            // echo  $pbc[1];


          
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>CBIC FORM</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets'); ?>/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets'); ?>/res.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript">
      $( document ).ready(function() {
      $( "#Phone" ).focus();
      });
  </script>
  <!-- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> -->
    <script type="text/javascript" src="<?php echo base_url('assets'); ?>/webcamjs/webcam.min.js"></script>
    <style>
        .profile img{width: 100%;height: 100%;}
        .profile video{ width: 100% !important;height: 150px !important;}
#my_camera{
display: inline-block;
width: 100px !important; 
 height: 100px !important;
 /*border: 1px solid black;*/
}
.layer2a label span {
    display: inline-block;
    float: left;
    width: auto;
    font-size: 14px;
    color: black;
    margin-right: 10px;
    height: 32px;
    padding-top: 5px;
}
.divcsss{padding: 0px !important;margin: 0px !important;width: 100%;text-align: center;}
.divcsss p{width: 100% !important;text-align: center;}
.divcsss input{width: 100% !important;text-align: center; float: none !important;}
.print_row{display: inline-block;width: 100%;}
.printer_names{display: inline-block;margin: 0px 0px;width: 100%;}
.print_n{display: inline-block;width: 100%; }
.print_p{display: inline-block;width: 100%; }
.print_visited_p{height: 15px !important; padding-top: 0px !important}
.print_floor{height: 15px !important; padding-top: 0px !important;}
.print_des_p{height: 15px !important; padding-top: 0px !important;}
.input_floor{height: 15px !important;border:none;}
.person{border: none;height: 15px !important;}
.part_b_Designation{border: none;height: 15px !important;}
.print_p_p{ width: 100% !important;text-align: center; margin-right: 0px !important;padding-top: 5px; height: 15px !important;}
.print_n_p{ width: 100% !important;text-align: center;margin-right: 0px !important;padding-top: 5px; height: 15px !important;}
.print_p_input{ width: 100% !important;max-width: 100% !important;text-align: center; float: none; height: 15px !important;}
.print_n_input{width: 100% !important;max-width: 100% !important;text-align: center;float: none; height: 15px !important;}
#Signature_of_the_visitor{display: none;}
#Signature_person_visited{display: none;}
#print_heading{display: none;width: 100%;text-align: center;}
#print_heading h6{display: block;width: 100%;text-align: center;font-size: 14px;text-transform: uppercase;}
#print_heading p{display: block;width: 100%;text-align: center;font-size: 10px;text-transform: uppercase;}
#bar_image{display: none;width: 100% !important;height: 50px;}
#bar_image p{width: 100%;}
/*#bar_image img{width: 100%;height: 100%;}*/
#date_time{display: none;}
.print_logo_div{width: 100%;}
.print_logo_a{width: 100% !important;float:none !important;text-align: center;}
.print_logo_a_img{width: 200px !important;margin-top: -10px;}
.heading-paracb{}
.heading-paracb p{font-size: 12px;}
.heading-paracb h6{font-size: 16px;}
.print_pass_id{display: block !important;font-size: 14px !important;text-align: center;margin-top: -10px;}
.print_pass_id_normal{display: none;}
</style>
</head>
