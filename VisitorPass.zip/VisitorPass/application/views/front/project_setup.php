<!DOCTYPE html>
<html>
	<head>
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Project Setup</title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<style>
			.thankyou-grp {
	background-color: rgba(0,0,0,0.4);
	height: 100vh;
}
			.thankyou1a
			{
				margin: 20px 0px;
			}
			.thank-you-content {
	display: inline-block;
	max-width: 600px;
	box-shadow: 0px 0px 20px #8eb7e3;
	padding: 20px;
	margin-top: 5%;
	border-radius: 10px;
	/*min-height: 180px;*/
	background-color: white;
}
			.thank-you-content span {
	background-color: #449c44;
	border-radius: 100%;
	width: 70px;
	height: 70px;
	display: inline-block;
	padding: 8px;
	color: white;
	font-size: 40px;
	text-shadow: 0px 0px 3px #000;
}
			.thank-you-content h5 {
	font-size: 20px;
	font-weight: 500;
	display: inline-block;
	width: 90%;
	text-align: center;
	color:#000;
}
.ok-content {
    display: inline-block;
    float: left;
    width: 100%;
    padding: 5px 0px;
    text-align: center;
}
.ok-content a.btn {
	background-color: black;
	color: white !important;
	width: 130px;
	display: inline-block;
	font-size: 18px;
	font-weight: 500;
	margin-top: 10px;
	margin-bottom: 10px;
	text-transform: uppercase;
	text-decoration: none !important;
}
		</style>
	</head>
	<body>
		
		<div class="container-fluid thankyou-grp">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center thankyou1a">
						<div class="thank-you-content">
							<!-- <span>&#10003;</span> -->
							<!-- <h5>" Your Visitor Pass request has been submitted."<br> Thank you </h5> -->
							<div class="ok-content">
								<a href="<?php echo base_url('setup-start');; ?>" class="btn">
									Install
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>