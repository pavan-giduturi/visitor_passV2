    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $Title=$editContent->Title; 
    $Chapter=$editContent->Chapter; 
    $message=$editContent->message; 
    $Description=$editContent->Description; 
    $Date=$editContent->Date; 
    $Post_BY=$editContent->Post_BY; 
    $status=$editContent->status; 
    $addEdit= base_url('admin-message-update');
    $name="Update";
    }else{
    $id=''; 
    $Title=''; 
    $Chapter=''; 
    $message=''; 
    $Description=''; 
    $Date=''; 
    $Post_BY=''; 
    $status=''; 
    $addEdit= base_url('admin-message-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Message Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Message Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Message Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Title</label>

                  <input class="form-control" type="text" name="Title" placeholder="Enter Title" value="<?php echo $Title; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Chapter</label>

                  <input class="form-control" type="text" name="Chapter" placeholder="EX : DEUTERONOMY 1:2-46; NUMBERS 14" value="<?php echo $Chapter; ?>" required>

                </div>

                
               
               
               
                <div class="form-group col-md-6">

                  <label class="control-label">Description</label>

                  <textarea class="form-control" id="messageDescription"  name="Description" placeholder="Enter Description" required><?php echo $Description; ?></textarea>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Date</label>

                  <input class="form-control" type="date" name="Date" placeholder="date" value="<?php echo $Date; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Post_BY</label>

                  <input class="form-control" type="text" name="Post_BY" placeholder="Enter Post By" value="<?php echo $Post_BY; ?>" required>

                </div>
                  <div class="form-group col-md-6">

                  <label class="control-label">Message Image</label>

                    <?php if($message == ""){ ?>

                    <input type="file" id="message" placeholder="Enter Page Name" name="message">

                    <?php }else { ?>

                    <input type="file" name="message"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/message/').$message; ?>" alt="profile image" style="height: 100px; width: 50%;">
                    </div>

                    <input type="hidden" name="hiddenmessage"  class="form-control boxed" value="<?php echo $message; ?>"> 

                    <?php } ?>  

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                      

                    </select>

                </div>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>