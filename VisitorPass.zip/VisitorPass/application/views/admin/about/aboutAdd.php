    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $Title=$editContent->Title; 
    $Description_1=$editContent->Description_1; 
    $about=$editContent->about; 
    $status=$editContent->status; 
    // $Description_2=$editContent->Description_2; 
    // $Our_Vision=$editContent->Our_Vision; 
    // $OUR_MISSIONOUR_MISSION=$editContent->OUR_MISSIONOUR_MISSION; 
    // $OUR_LEADERSHIP=$editContent->OUR_LEADERSHIP; 
    $addEdit= base_url('admin-about-update');
    $name="Update";
    }else{
    $id=''; 
    $Title=''; 
    $Description_1=''; 
    $about=''; 
    $status=''; 
    // $Description_2=''; 
    // $Our_Vision=''; 
    // $OUR_MISSION=''; 
    // $OUR_LEADERSHIP=''; 
    $addEdit= base_url('admin-about-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>about Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">about Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">about Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Title</label>

                  <input class="form-control" type="text" name="Title" placeholder="Enter Title" value="<?php echo $Title; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Description </label>

                  <textarea class="form-control" id="aboutDescription_1" name="Description_1" placeholder="Enter content" value="" required><?php echo $Description_1; ?></textarea>

                </div>
                
                  <div class="form-group col-md-6">

                  <label class="control-label">About Image</label>

                    <?php if($about == ""){ ?>

                    <input type="file" id="about" placeholder="Enter Page Name" name="about">

                    <?php }else { ?>

                    <input type="file" name="about"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/about/').$about; ?>" alt="profile image" style="height: 100px; width: 50%;">
                    </div>

                    <input type="hidden" name="hiddenabout"  class="form-control boxed" value="<?php echo $about; ?>"> 

                    <?php } ?>  

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                      

                    </select>

                </div>

                 <?php /*<div class="form-group col-md-6">

                  <label class="control-label">Description B</label>

                  <textarea class="form-control" id="aboutDescription_2" name="Description_2" placeholder="Enter content" value="" required><?php echo $Description_2; ?></textarea>

                </div>

                
                <div class="form-group col-md-6">

                  <label class="control-label">Our_Vision</label>

                  <textarea class="form-control" id="Our_Vision" name="Our_Vision" placeholder="Our_Vision" value="" required><?php echo $Our_Vision; ?></textarea>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">OUR_MISSION</label>

                 <textarea class="form-control" id="OUR_MISSION" name="OUR_MISSION" placeholder="OUR_MISSION" value="" required><?php echo $OUR_MISSION; ?></textarea>

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">OUR_LEADERSHIP</label>

                 <textarea class="form-control" id="OUR_LEADERSHIP" name="OUR_LEADERSHIP" placeholder="OUR_LEADERSHIP" value="" required><?php echo $OUR_LEADERSHIP; ?></textarea>

                </div> */ ?>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>