
<!--model start-->

 <div id="deleteModal" class="modal fade" role="dialog">

          <div class="modal-dialog">



            <!-- Modal content-->

            <div class="modal-content">

              <div class="modal-header">

                <h4 class="modal-title">Are you sure you want to delete!</h4>

              </div>

              <div class="modal-body" id="deleteModalBody">

                <a id="delete" class="btn btn-warning">Delete</a>

                <a id="cancel" data-dismiss="modal" class="btn btn-info">Cancel</a>

              </div>

            </div>



          </div>

        </div>

        <!-- End Modal -->


<!-- Essential javascripts for application to work-->
    <script src="<?php echo base_url('adminassets') ?>/js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo base_url('adminassets') ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url('adminassets') ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('adminassets') ?>/<?php echo base_url('adminassets') ?>/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo base_url('adminassets') ?>/js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="<?php echo base_url('adminassets') ?>/js/plugins/chart.js"></script>
    <script type="text/javascript">
      var data = {
      	labels: ["January", "February", "March", "April", "May"],
      	datasets: [
      		{
      			label: "My First dataset",
      			fillColor: "rgba(220,220,220,0.2)",
      			strokeColor: "rgba(220,220,220,1)",
      			pointColor: "rgba(220,220,220,1)",
      			pointStrokeColor: "#fff",
      			pointHighlightFill: "#fff",
      			pointHighlightStroke: "rgba(220,220,220,1)",
      			data: [65, 59, 80, 81, 56]
      		},
      		{
      			label: "My Second dataset",
      			fillColor: "rgba(151,187,205,0.2)",
      			strokeColor: "rgba(151,187,205,1)",
      			pointColor: "rgba(151,187,205,1)",
      			pointStrokeColor: "#fff",
      			pointHighlightFill: "#fff",
      			pointHighlightStroke: "rgba(151,187,205,1)",
      			data: [28, 48, 40, 19, 86]
      		}
      	]
      };
      var pdata = [
      	{
      		value: 300,
      		color: "#46BFBD",
      		highlight: "#5AD3D1",
      		label: "Complete"
      	},
      	{
      		value: 50,
      		color:"#F7464A",
      		highlight: "#FF5A5E",
      		label: "In-Progress"
      	}
      ]
      
      var ctxl = $("#lineChartDemo").get(0).getContext("2d");
      var lineChart = new Chart(ctxl).Line(data);
      
      var ctxp = $("#pieChartDemo").get(0).getContext("2d");
      var pieChart = new Chart(ctxp).Pie(pdata);
    </script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>

     <script type="text/javascript">

       function deleteModals(cmsId,url) {

            var action = url+cmsId;

            $("#delete").attr("href",action);

            $("#cancel").attr("href",action);

        }


      $(function(){

      $('.alert').delay(2000).fadeOut(2000);

      });
    </script>

     <script>
        function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 46 || charCode > 57)) {
        return false;
        }
        return true;
        }

        function isAlfa(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 32 && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
        return false;
        }
        return true;
        }
        </script>

        
        <script type="text/javascript">
          function statusChange(id,status){
                  $.ajax(
                  {
                  type:"post",
                  url: "<?php echo base_url('Admin/getChangeStatus'); ?>",
                  data:{'id':id,'status':status},
                  success:function(response)
                    { 
                      document.location.assign("<?php echo base_url('admin-reviews'); ?>");
                    }  
                  });
              }
        </script>

        <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
        <script>
                        CKEDITOR.replace( 'TestmonialsDescription' );
                        CKEDITOR.replace( 'goldDescription' );
                        CKEDITOR.replace( 'buyNowLink' );
                        CKEDITOR.replace( 'eventDesciption' );
                        CKEDITOR.replace( 'aboutDescription_1' );
                        CKEDITOR.replace( 'aboutDescription_2' );
                        CKEDITOR.replace( 'Our_Vision' );
                        CKEDITOR.replace( 'OUR_MISSION' );
                        CKEDITOR.replace( 'OUR_LEADERSHIP' );
                        CKEDITOR.replace( 'siteEmailDes' );
        </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    
    <script type="text/javascript">
    $("form[name='goteForm']").validate({
    rules: {
    Title: {
    required: true,
    },
    First_Name: {
    required: true,
    minlength: 3,
    maxlength: 10,
    pattern:true,
    },
    Last_Name: {
    required: true,
    minlength: 3,
    maxlength: 10,
    pattern:true,
    },
    Church: {
    required: true,
    },
    Address: {
    required: true,
    },
    Email: {
    required: true,
    email: true
    },
    Phone:{
    required:true,
    number:true,
    minlength:7,
    maxlength:15,
    },
    },
    messages: {
    Title: {
    required: "Please enter your title",
    },
    First_Name: {
    required: "Please enter your first name",
    minlength: "name must be at least 3 characters long",
    maxlength: "name max length 15 characters",
    },
    Last_Name: {
    required: "Please enter your first name",
    minlength: "name must be at least 3 characters long",
    maxlength: "name max length 15 characters",
    },
    Church:{
    required: "Please enter church ",
    },
    Address:{
    required: "Please enter church ",
    },
    Email:{
    required: "Please enter a valid email address",
    },
    Phone:{
    required: "Please enter your mobile number",
    minlength: "mobile number at least 7 characters",
    maxlength: "mobile number max length 15 characters",
    },
    },
    
    submitHandler: function(form) {
    form.submit();
    }
    });
    </script>

  </body>
</html>