    <?php 
    if($site!=""){
    $id=$site->id; 
    $siteTitle=$site->siteTitle; 
    $siteAddress=$site->siteAddress; 
    $siteFacebook=$site->siteFacebook; 
    $siteTwitter=$site->siteTwitter; 
    $siteInstagram=$site->siteInstagram; 
    $siteYoutube=$site->siteYoutube; 
    $googleplus=$site->googleplus; 
    $linkedin=$site->linkedin; 
    $vk=$site->vk; 
    $siteFooter=$site->siteFooter; 
    $siteLogo=$site->siteLogo; 
    $Map=$site->Map; 
    $mobile=$site->mobile; 
    $siteEmail=$site->siteEmail; 
    $addEdit= base_url('admin-site-update');
    $name="Update";

    }else{
      $id=''; 
    $siteTitle=''; 
    $siteAddress=''; 
    $siteFacebook=''; 
    $siteTwitter=''; 
    $siteInstagram=''; 
    $siteYoutube=''; 
    $googleplus=''; 
    $linkedin=''; 
    $vk=''; 
    $siteFooter=''; 
    $siteLogo=''; 
    $Map=''; 
    $mobile=''; 
    $siteEmail=''; 
    $addEdit= base_url('admin-site-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Site settings</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Site Settings</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Site settings</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Site Title</label>

                  <input class="form-control" type="text" name="siteTitle" placeholder="Enter name" value="<?php echo $siteTitle; ?>" required>

                </div> 
               
               <!--  <div class="form-group col-md-6">

                  <label class="control-label">Facebook</label>

                  <input class="form-control" type="text" name="siteFacebook" placeholder="Enter Facebook" value="<?php echo $siteFacebook; ?>" required>

                </div>

                <div class="form-group col-md-6">

                  <label class="control-label">Twitter</label>

                  <input class="form-control" type="text" name="siteTwitter" placeholder="Twitter" value="<?php echo $siteTwitter; ?>" required>

                </div>

                <div class="form-group col-md-6">

                  <label class="control-label">Instagram</label>

                  <input class="form-control" type="text" name="siteInstagram" placeholder="Enter Instagram" value="<?php echo $siteInstagram; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Youtube</label>

                  <input class="form-control" type="text" name="siteYoutube" placeholder="Enter Youtube" value="<?php echo $siteYoutube; ?>" required>

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">Google+</label>

                  <input class="form-control" type="text" name="googleplus" placeholder="Enter Google+" value="<?php echo $googleplus; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Linkedin</label>

                  <input class="form-control" type="text" name="linkedin" placeholder="Enter Linkedin" value="<?php echo $linkedin; ?>" required>

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">vk</label>

                  <input class="form-control" type="text" name="vk" placeholder="Enter vk" value="<?php echo $vk; ?>" required>

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">Google Map Iframe</label>

                  <input class="form-control" type="text" name="Map" placeholder="Enter Map" value="<?php echo $Map; ?>" required>

                </div>
 -->            <div class="form-group col-md-6">

                <label class="control-label">Site Email</label>

                <textarea class="form-control"  name="siteEmail" placeholder="Enter Site Email"  required><?php echo $siteEmail; ?></textarea>

              </div>
               
                <div class="form-group col-md-6">

                <label class="control-label">Mobile No</label>

                <input class="form-control" type="text" name="mobile" placeholder="Enter mobile" value="<?php echo $mobile; ?>" required>

              </div>
               <div class="form-group col-md-6">

                  <label class="control-label">Footer Year</label>

                  <input class="form-control" type="text" name="siteFooter" placeholder="Enter Year" value="<?php echo $siteFooter; ?>" required>

                </div>

                 <div class="form-group col-md-6">

                  <label class="control-label">Site Logo</label>

                    <?php if($siteLogo == ""){ ?>

                    <input type="file" id="siteLogo" placeholder="Enter Page Name" name="siteLogo">

                    <?php }else { ?>

                    <input type="file" name="siteLogo"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/site/').$siteLogo; ?>" alt="profile image" style="height: 200px; width: 200px;">
                    </div>

                    <input type="hidden" name="hiddensiteLogo"  class="form-control boxed" value="<?php echo $siteLogo; ?>"> 

                    <?php } ?>  

                </div>

                 <div class="form-group col-md-6">

                  <label class="control-label">Site Headings</label>

                  <textarea class="form-control" name="siteAddress" placeholder="Enter Site Details" id="siteEmailDes"><?php echo $siteAddress; ?></textarea>

                </div>
               


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>