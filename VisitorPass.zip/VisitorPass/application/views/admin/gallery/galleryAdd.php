    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $filter=$editContent->filter; 
    $gallery=$editContent->gallery; 
    $status=$editContent->status; 
    $addEdit= base_url('admin-gallery-update');
    $name="Update";
    }else{
    $id=''; 
    $filter=''; 
    $gallery=''; 
    $status=''; 
    $addEdit= base_url('admin-gallery-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Gallery Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Gallery Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Gallery Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Gallery Filter</label>

                  <select class="form-control" name="filter">
                    <option>Select filter</option>
                    <option value="OTHER" <?php if($filter == 'OTHER'){ echo 'selected';} ?>>OTHER</option>
                    <option value="GALLERY" <?php if($filter == 'GALLERY'){ echo 'selected';} ?>>GALLERY</option>
                    <option value="NEWS" <?php if($filter == 'NEWS'){ echo 'selected';} ?>>NEWS</option>
                    <option value="EVENTS" <?php if($filter == 'EVENTS'){ echo 'selected';} ?>>EVENTS</option>
                      

                    </select>

                </div>

               

                
               
               
                 <div class="form-group col-md-6">

                  <label class="control-label"> gallery Image</label>

                    <?php if($gallery == ""){ ?>

                    <input type="file" id="gallery" placeholder="Enter Page Name" name="gallery">

                    <?php }else { ?>

                    <input type="file" name="gallery"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/gallery/').$gallery; ?>" alt="profile image" style="height: 100px; width: 50%;">
                    </div>

                    <input type="hidden" name="hiddengallery"  class="form-control boxed" value="<?php echo $gallery; ?>"> 

                    <?php } ?>  

                </div>
               
                <div class="form-group col-md-6">

                  <label class="control-label">Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                      

                    </select>

                </div>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>