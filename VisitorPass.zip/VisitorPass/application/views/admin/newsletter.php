 <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Dashboard</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">NEWSLETTER Dashboard</li>
          <!-- <li class="breadcrumb-item active"><a href="#">Simple Tables</a></li> -->
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-header">
            <h3 class="tile-title">NEWSLETTER List </h3> 
           
            </div>
            <table class="table table-responsive">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Email</th>
                  <th>Action</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $sno=1; foreach ($news as $c) { ?>
                
                <tr class="table-info">
                  <td><?php echo $sno; ?></td>
                  <td><?php echo $c->email; ?></td>
                  <td>
                     <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="deleteModals('<?php echo $c->id; ?>','<?php echo base_url('admin-newsletter-delete/'); ?>')"><i class="fa fa-times" aria-hidden="true"></i></a>
                  </td>
                </tr>
                <?php $sno++; } ?>
               
              </tbody>
            </table>
          </div>
        </div>
        <div class="clearfix"></div>
        
       
      </div>
    </main>

    <style type="text/css">
      .tile-header{display: inline-block;width: 100%;height: auto;margin: 10px 5px;}
      .tile-header h3{display: inline-block;float: left;}
      .tile-header a{display: inline-block;float: right;}
    </style>