    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $productTitle=$editContent->productTitle; 
    // $productPrice=$editContent->productPrice; 
    $productImage=$editContent->productImage; 
    $buyNowLink=$editContent->buyNowLink; 
    $status=$editContent->status; 
    $addEdit= base_url('admin-shop-update');
    $name="Update";
    }else{
    $id=''; 
    $productTitle=''; 
    // $productPrice=''; 
    $productImage=''; 
    $buyNowLink=''; 
    $status=''; 
    $addEdit= base_url('admin-shop-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Product Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Product Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Product Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Product Title</label>

                  <input class="form-control" type="text" name="productTitle" placeholder="Enter Title" value="<?php echo $productTitle; ?>" required>

                </div> 
                
                
               
               
                 <div class="form-group col-md-6">

                  <label class="control-label">Product Image</label>

                    <?php if($productImage == ""){ ?>

                    <input type="file" id="productImage" placeholder="Enter Page Name" name="productImage">

                    <?php }else { ?>

                    <input type="file" name="productImage"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/shop/').$productImage; ?>" alt="profile image" style="height: 100px; width: 50%;">
                    </div>

                    <input type="hidden" name="hiddenproductImage"  class="form-control boxed" value="<?php echo $productImage; ?>"> 

                    <?php } ?>  

                </div>
               <?php /* <div class="form-group col-md-6">

                  <label class="control-label">Product Price</label>

                  <input class="form-control" type="text" name="productPrice" placeholder="Enter Price" value="<?php echo $productPrice; ?>" required>

                </div>*/ ?>

                <div class="form-group col-md-6">

                  <label class="control-label">Description</label>

                  <textarea class="form-control" id="buyNowLink" name="buyNowLink" placeholder="Enter Description" value="" required><?php echo $buyNowLink; ?></textarea>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                      

                    </select>

                </div>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>