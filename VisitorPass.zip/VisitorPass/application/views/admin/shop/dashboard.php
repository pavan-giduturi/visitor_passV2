 <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Visitor Records Dashboard</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Records Dashboard</li>
          <!-- <li class="breadcrumb-item active"><a href="#">Simple Tables</a></li> -->
        </ul>
      </div> 
      <div class="col-md-12 bg-info p-2 ">
        <div class="row">
        <div class="col-md-8">
          <form class="form-inline" action="<?php echo base_url('visitor-from-to-date'); ?>" method="post">
          <div class="form-group">
          <label class="m-1 ">From </label>
          <input type="date" class="form-control" name="from"required>
          </div>
          <div class="form-group">
          <label class="m-1"> To </label>
          <input type="date" class="form-control" name="to" required>
          </div>
          <button type="submit" class="btn btn-danger m-1">Search</button>
          </form>
        </div>
        <div class="col-md-4">
          <form class="form-inline" action="<?php echo base_url('visitor-date-filter'); ?>" method="post">
          <div class="form-group">
          <label class="m-1">Date : </label>
          <input type="date" class="form-control" name="singleDate" required="required">
          </div>
          <button type="submit" class="btn btn-danger m-1">Search</button>
          </form>
        </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-header">
            <h3 class="tile-title">Visitors List </h3> 
           
            </div>
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Visitor ID</th>
                  <th>Name</th>
                  <th>Image</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>In-Time</th>
                  <th>visited Person</th>
                  <th>Purpose of visit</th>
                  <th>Out-Time</th>
                  <th>Action</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $sno=1; foreach ($records as $c) { ?>
                
                <tr class="table-info">
                  <td><?php echo $sno; ?></td>
                  <td><?php echo $c->SLNO; ?></td>
                  <td><?php echo $c->Name; ?></td>
                  <td><img src="<?php echo base_url('source/upload/').$c->profile_image; ?>" height='50' width='50'></td>
                  <td><?php echo $c->Phone; ?></td>
                  <td><?php echo $c->Add_content; ?></td>
                  <td><?php echo $c->in_time; ?></td>
                  <td><?php echo $c->Person_to_be_visited; ?></td>
                  <td><?php echo $c->Purpose_of_visit; ?></td>
                  <td><?php echo $c->out_time; ?></td>                 
                  <td>                  
                     <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="deleteModals('<?php echo $c->id; ?>','<?php echo base_url('admin-shop-delete/'); ?>')"><i class="fa fa-times" aria-hidden="true"></i></a>
                  </td>
                </tr>
                <?php $sno++; } ?>
               
              </tbody>
            </table>
          </div>
        </div>
        <div class="clearfix"></div>
        
       
      </div>
    </main>

    <style type="text/css">
      .tile-header{display: inline-block;width: 100%;height: auto;margin: 10px 5px;}
      .tile-header h3{display: inline-block;float: left;}
      .tile-header a{display: inline-block;float: right;}
    </style>