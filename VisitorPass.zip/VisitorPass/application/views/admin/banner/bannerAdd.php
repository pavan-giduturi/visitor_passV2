    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $bannerTitle=$editContent->bannerTitle; 
    $bannerDescription=$editContent->bannerDescription; 
    $bannerImage=$editContent->bannerImage; 
    $status=$editContent->status; 
    $addEdit= base_url('admin-banner-update');
    $name="Update";
    }else{
    $id=''; 
    $bannerTitle=''; 
    $bannerDescription=''; 
    $bannerImage=''; 
    $status=''; 
    $addEdit= base_url('admin-banner-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Banners Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Banners Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Banners Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Banner Title</label>

                  <input class="form-control" type="text" name="bannerTitle" placeholder="Enter name" value="<?php echo $bannerTitle; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Banner Description</label>

                  <textarea class="form-control" name="bannerDescription" placeholder="Enter banner Description"><?php echo $bannerDescription; ?></textarea>

                </div>
               
               
                 <div class="form-group col-md-6">

                  <label class="control-label">Banner Image</label>

                    <?php if($bannerImage == ""){ ?>

                    <input type="file" id="bannerImage" placeholder="Enter Page Name" name="bannerImage">

                    <?php }else { ?>

                    <input type="file" name="bannerImage"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/banner/').$bannerImage; ?>" alt="profile image" style="height: 100px; width: 50%;">
                    </div>

                    <input type="hidden" name="hiddenbannerImage"  class="form-control boxed" value="<?php echo $bannerImage; ?>"> 

                    <?php } ?>  

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">Banner Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                    <?php echo $bannerDescription; ?>
                      

                    </select>

                </div>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>