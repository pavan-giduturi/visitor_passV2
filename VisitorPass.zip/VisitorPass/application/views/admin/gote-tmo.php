 <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Dashboard</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">GOTE/TMO Dashboard</li>
          <!-- <li class="breadcrumb-item active"><a href="#">Simple Tables</a></li> -->
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-header">
            <h3 class="tile-title">GOTE/TMO List </h3> 
           
            </div>
            <table class="table table-responsive">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Title</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>church</th>
                  <th>Address</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Hotel Info</th>
                  <th>Break Out Sessions</th>
                  <th>Hotel Reservation</th>
                  <th>Form</th>
                  <th>Action</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $sno=1; foreach ($gote as $c) { ?>
                
                <tr class="table-info">
                  <td><?php echo $sno; ?></td>
                  <td><?php echo $c->Title; ?></td>
                  <td><?php echo $c->First_Name; ?></td>
                  <td><?php echo $c->Last_Name; ?></td>
                  <td><?php echo $c->church; ?></td>                 
                  <td><?php echo $c->Address; ?></td>                 
                  <td><?php echo $c->Email; ?></td>                 
                  <td><?php echo $c->Phone; ?></td>                 
                  <td><?php echo $c->Hotel_Info; ?></td>                 
                  <td><?php echo $c->Break_Out_Sessions; ?></td>                 
                  <td><?php echo $c->Hotel_Reservation; ?></td>                 
                  <td><?php echo $c->Form_Role; ?></td>                 
                  <td>
                     <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="deleteModals('<?php echo $c->id; ?>','<?php echo base_url('admin-gote-delete/'); ?>')"><i class="fa fa-times" aria-hidden="true"></i></a>
                  </td>
                </tr>
                <?php $sno++; } ?>
               
              </tbody>
            </table>
          </div>
        </div>
        <div class="clearfix"></div>
        
       
      </div>
    </main>

    <style type="text/css">
      .tile-header{display: inline-block;width: 100%;height: auto;margin: 10px 5px;}
      .tile-header h3{display: inline-block;float: left;}
      .tile-header a{display: inline-block;float: right;}
    </style>