    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $Title=$editContent->Title; 
    $Description=$editContent->Description; 
    $date=$editContent->date; 
    $status=$editContent->status; 
    $addEdit= base_url('admin-testmonials-update');
    $name="Update";
    }else{
    $id=''; 
    $Title=''; 
    $Description=''; 
    $date=''; 
    $status=''; 
    $addEdit= base_url('admin-testmonials-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Testmonials Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Testmonials Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Testmonials Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Title</label>

                  <input class="form-control" type="text" name="Title" placeholder="Enter Title" value="<?php echo $Title; ?>" required>

                </div> 
               

                
               
               
               
                <div class="form-group col-md-6">

                  <label class="control-label">Description</label>

                  <textarea class="form-control" id="TestmonialsDescription"  name="Description" placeholder="Enter Description" required><?php echo $Description; ?></textarea>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">date</label>

                  <input class="form-control" type="date" name="date" placeholder="date" value="<?php echo $date; ?>" required>

                </div> 
                
                
                <div class="form-group col-md-6">

                  <label class="control-label">Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                      

                    </select>

                </div>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>
