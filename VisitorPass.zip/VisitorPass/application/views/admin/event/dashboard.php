 <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Dashboard</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Services Dashboard</li>
          <!-- <li class="breadcrumb-item active"><a href="#">Simple Tables</a></li> -->
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-header">
            <h3 class="tile-title">Services Page </h3> 
            <!-- <a href="<?php echo base_url('admin-event-add-page'); ?>" class="btn btn-success btn-sm">ADD</a> -->
            </div>
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Title</th>
                  <!-- <th>Church</th> -->
                  <th>Image</th>
                  <th>Description</th>
                 <!--  <th>Date</th>
                  <th>Time</th> -->
                  <!-- <th>status</th> -->
                  <th>Action</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $sno=1; foreach ($event as $c) { ?>
                
                <tr class="table-info">
                  <td><?php echo $sno; ?></td>
                  <td><?php echo $c->Title; ?></td>
                  <!-- <td><?php echo $c->Church; ?></td> -->
                  <td><img src="<?php echo base_url('uploads/event/').$c->event; ?>" height='50' width='50'></td>
                  <td><?php echo $c->Desciption; ?></td>
                 <!--  <td>
                    <?php  echo date("jS F, Y", strtotime($c->date)); ?>
                  </td>
                  <td><?php echo $c->Time; ?></td> -->
                  <!-- <td><?php if($c->status =='1'){ echo 'Active';}else{  echo 'Inactive' ;} ?></td> -->
                 
                  <td>
                    <a href="<?php echo base_url('admin-event-add-page/').$c->id; ?>" class='btn btn-success btn-sm'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                  
                     <!-- <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="deleteModals('<?php echo $c->id; ?>','<?php echo base_url('admin-event-delete/'); ?>')"><i class="fa fa-times" aria-hidden="true"></i></a> -->
                  </td>
                </tr>
                <?php $sno++; } ?>
               
              </tbody>
            </table>
          </div>
        </div>
        <div class="clearfix"></div>
        
       
      </div>
    </main>

    <style type="text/css">
      .tile-header{display: inline-block;width: 100%;height: auto;margin: 10px 5px;}
      .tile-header h3{display: inline-block;float: left;}
      .tile-header a{display: inline-block;float: right;}
    </style>