    <?php 
    if($editContent!=""){
    $id=$editContent->id; 
    $Title=$editContent->Title; 
    // $Church=$editContent->Church; 
    $event=$editContent->event; 
    $Desciption=$editContent->Desciption; 
    // $date=$editContent->date; 
    // $Time=$editContent->Time; 
    $status=$editContent->status; 
    $addEdit= base_url('admin-event-update');
    $name="Update";
    }else{
    $id=''; 
    $Title=''; 
    // $Church=''; 
    $event=''; 
    $Desciption=''; 
    // $date=''; 
    // $Time=''; 
    $status=''; 
    $addEdit= base_url('admin-event-add');
    $name="Add";
    }


    ?>

<main class="app-content">

      <div class="app-title">

        <div>

          <h1><i class="fa fa-edit"></i>Services Add</h1>

        </div>

        <ul class="app-breadcrumb breadcrumb">

          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>

          <li class="breadcrumb-item">Services Add</li>

        </ul>

      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="tile">

            <h3 class="tile-title">Services Add</h3>

            <div class="tile-body">

              <form class="row" method="post" action="<?php echo $addEdit; ?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="form-group col-md-6">

                  <label class="control-label">Title</label>

                  <input class="form-control" type="text" name="Title" placeholder="Enter Title" value="<?php echo $Title; ?>" required>

                </div> 
               <!--  <div class="form-group col-md-6">

                  <label class="control-label">Church</label>

                  <input class="form-control" type="text" name="Church" placeholder="Ex : CHURCH OF JESUS CHRIST" value="<?php echo $Church; ?>" required>

                </div> -->

                
               
               
               
                <div class="form-group col-md-6">

                  <label class="control-label">Desciption</label>

                  <textarea class="form-control" id="eventDesciption"  name="Desciption" placeholder="Enter Desciption" required><?php echo $Desciption; ?></textarea>

                </div> 
                <!-- <div class="form-group col-md-6">

                  <label class="control-label">Date</label>

                  <input class="form-control" type="date" name="date" placeholder="date" value="<?php echo $date; ?>" required>

                </div> 
                <div class="form-group col-md-6">

                  <label class="control-label">Time</label>

                  <input class="form-control" type="time" name="Time" placeholder="Enter Time" value="<?php echo $Time; ?>" required>

                </div> -->
                  <div class="form-group col-md-6">

                  <label class="control-label">Service Banner Image</label>

                    <?php if($event == ""){ ?>

                    <input type="file" id="event" placeholder="Enter Page Name" name="event">

                    <?php }else { ?>

                    <input type="file" name="event"  class="form-control boxed" placeholder="" > 
                    <div class="col-md-12">
                      
                    <img src="<?php echo base_url('uploads/event/').$event; ?>" alt="profile image" style="height: 100px; width: 50%;">
                    </div>

                    <input type="hidden" name="hiddenevent"  class="form-control boxed" value="<?php echo $event; ?>"> 

                    <?php } ?>  

                </div>
                <div class="form-group col-md-6">

                  <label class="control-label">Status</label>

                  <select class="form-control" name="status">
                    <option>Select Status</option>
                    <option value="1" <?php if($status == '1'){ echo 'selected';} ?>>Active</option>
                    <option value="2" <?php if($status == '2'){ echo 'selected';} ?>>Inactive</option>
                      

                    </select>

                </div>


               

                <div class="form-group col-md-4 align-self-end">

                  <button type="submit" class="btn btn-primary" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $name; ?></button>

                </div>

              </form>

            </div>

          </div>

        </div>

      </div>

    </main>