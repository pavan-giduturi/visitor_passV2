<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['dsn']      The full DSN string describe a connection to the database.
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database driver. e.g.: mysqli.
|			Currently supported:
|				 cubrid, ibase, mssql, mysql, mysqli, oci8,
|				 odbc, pdo, postgre, sqlite, sqlite3, sqlsrv
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Query Builder class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|				 NOTE: For MySQL and MySQLi databases, this setting is only used
| 				 as a backup if your server is running PHP < 5.2.3 or MySQL < 5.0.7
|				 (and in table creation queries made with DB Forge).
| 				 There is an incompatibility in PHP with mysql_real_escape_string() which
| 				 can make your site vulnerable to SQL injection if you are using a
| 				 multi-byte character set and are running versions lower than these.
| 				 Sites using Latin-1 or UTF-8 database character set and collation are unaffected.
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['encrypt']  Whether or not to use an encrypted connection.
|
|			'mysql' (deprecated), 'sqlsrv' and 'pdo/sqlsrv' drivers accept TRUE/FALSE
|			'mysqli' and 'pdo/mysql' drivers accept an array with the following options:
|
|				'ssl_key'    - Path to the private key file
|				'ssl_cert'   - Path to the public key certificate file
|				'ssl_ca'     - Path to the certificate authority file
|				'ssl_capath' - Path to a directory containing trusted CA certificates in PEM format
|				'ssl_cipher' - List of *allowed* ciphers to be used for the encryption, separated by colons (':')
|				'ssl_verify' - TRUE/FALSE; Whether verify the server certificate or not
|
|	['compress'] Whether or not to use client compression (MySQL only)
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|	['ssl_options']	Used to set various SSL options that can be used when making SSL connections.
|	['failover'] array - A array with 0 or more data for connections if the main should fail.
|	['save_queries'] TRUE/FALSE - Whether to "save" all executed queries.
| 				NOTE: Disabling this will also effectively disable both
| 				$this->db->last_query() and profiling of DB queries.
| 				When you run a query, with this setting set to TRUE (default),
| 				CodeIgniter will store the SQL statement for debugging purposes.
| 				However, this may cause high memory usage, especially if you run
| 				a lot of SQL queries ... disable this to avoid that problem.
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $query_builder variables lets you determine whether or not to load
| the query builder class.
*/
$hostname = 'localhost';
$username = 'root';
$password = '';

$conn = new mysqli($hostname, $username, $password);
$create_db_query  = "CREATE DATABASe visitor_p";
$conn->query($create_db_query);

$connected = new mysqli($hostname, $username, $password, 'visitor_p');
				$admin_crate = "CREATE TABLE `tbl_admin` (
				`id` int(11) NOT NULL,
				`firstName` varchar(100) NOT NULL,
				`lastName` varchar(100) NOT NULL,
				`profileImage` varchar(50) NOT NULL,
				`email` varchar(100) NOT NULL,
				`password` varchar(255) NOT NULL,
				`phoneNumber` bigint(15) NOT NULL,
				`country` tinyint(3) NOT NULL,
				`state` tinyint(3) NOT NULL,
				`city` tinyint(3) NOT NULL,
				`zipcode` int(11) NOT NULL,
				`roleType` varchar(250) NOT NULL,
				`collegeId` tinyint(2) NOT NULL,
				`status` tinyint(2) NOT NULL,
				`createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				$connected->query($admin_crate);
				$connected->query("ALTER TABLE `tbl_admin` ADD PRIMARY KEY (`id`);");
				$connected->query("ALTER TABLE `tbl_admin` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT");

				$pass_table_create = "CREATE TABLE `tbl_passes` (
  `id` int(11) NOT NULL,
  `SLNO` varchar(250) NOT NULL,
  `pass_no` varchar(250) NOT NULL,
  `PDate` varchar(250) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Designation` varchar(250) NOT NULL,
  `Floor` varchar(250) NOT NULL,
  `Add_content` text NOT NULL,
  `ID_Proof` varchar(250) NOT NULL,
  `Phone` varchar(250) NOT NULL,
  `Person_to_be_visited` text NOT NULL,
  `part_b_Designation` varchar(250) NOT NULL,
  `Purpose_of_visit` varchar(250) NOT NULL,
  `in_time` varchar(250) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `Remarks` text NOT NULL,
  `profile_image` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

				$connected->query($pass_table_create);

				$connected->query("ALTER TABLE `tbl_passes`
  ADD PRIMARY KEY (`id`)");


				$connected->query("ALTER TABLE `tbl_passes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT");

				$sitesettings_create = "CREATE TABLE `tbl_site_settings` (
				`id` tinyint(3) NOT NULL,
				`siteTitle` varchar(100) NOT NULL,
				`siteLogo` varchar(255) NOT NULL,
				`siteAddress` text NOT NULL,
				`siteEmail` text NOT NULL,
				`password` varchar(250) NOT NULL,
				`siteFacebook` varchar(100) NOT NULL,
				`siteTwitter` varchar(100) NOT NULL,
				`siteInstagram` varchar(100) NOT NULL,
				`siteYoutube` varchar(100) NOT NULL,
				`googleplus` varchar(250) NOT NULL,
				`linkedin` varchar(250) NOT NULL,
				`vk` varchar(250) NOT NULL,
				`siteFooter` varchar(255) NOT NULL,
				`Map` text NOT NULL,
				`mobile` varchar(50) NOT NULL,
				`status` tinyint(2) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				$connected->query($sitesettings_create);
				$connected->query("ALTER TABLE `tbl_site_settings` ADD PRIMARY KEY (`id`)");
				$connected->query("ALTER TABLE `tbl_site_settings` MODIFY `id` tinyint(3) NOT NULL AUTO_INCREMENT");



$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
	'dsn'	=> '',
	'hostname' => 'localhost',
	'username' => 'root',
	'password' => '',
	'database' => 'visitor_p',
	// 'database' => 'db_cbic_s',
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);
